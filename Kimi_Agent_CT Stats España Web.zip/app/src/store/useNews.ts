import { useState, useEffect, useCallback } from 'react';
import type { News, Transfer, NewsType } from '@/types';

const NEWS_STORAGE_KEY = 'ctstats-news';
const TRANSFERS_STORAGE_KEY = 'ctstats-transfers';

const generateId = () => Math.random().toString(36).substring(2, 15);
const now = () => new Date().toISOString();

export const useNews = () => {
  const [news, setNews] = useState<Record<string, News>>({});
  const [transfers, setTransfers] = useState<Record<string, Transfer>>({});
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const storedNews = localStorage.getItem(NEWS_STORAGE_KEY);
    const storedTransfers = localStorage.getItem(TRANSFERS_STORAGE_KEY);
    
    if (storedNews) {
      try {
        setNews(JSON.parse(storedNews));
      } catch (e) {
        console.error('Error loading news:', e);
      }
    }
    
    if (storedTransfers) {
      try {
        setTransfers(JSON.parse(storedTransfers));
      } catch (e) {
        console.error('Error loading transfers:', e);
      }
    }
    
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(NEWS_STORAGE_KEY, JSON.stringify(news));
    }
  }, [news, isLoaded]);

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(TRANSFERS_STORAGE_KEY, JSON.stringify(transfers));
    }
  }, [transfers, isLoaded]);

  // News operations
  const addNews = useCallback((newsData: Omit<News, 'id' | 'createdAt' | 'updatedAt'>): string => {
    const id = generateId();
    const newNews: News = {
      ...newsData,
      id,
      createdAt: now(),
      updatedAt: now(),
    };
    
    setNews(prev => ({ ...prev, [id]: newNews }));
    return id;
  }, []);

  const updateNews = useCallback((id: string, updates: Partial<News>): boolean => {
    setNews(prev => {
      const item = prev[id];
      if (!item) return prev;
      
      return {
        ...prev,
        [id]: { ...item, ...updates, updatedAt: now() },
      };
    });
    return true;
  }, []);

  const deleteNews = useCallback((id: string): boolean => {
    setNews(prev => {
      const { [id]: _, ...rest } = prev;
      return rest;
    });
    return true;
  }, []);

  const publishNews = useCallback((id: string): boolean => {
    return updateNews(id, { status: 'published', publishedAt: now() });
  }, [updateNews]);

  const getNewsById = useCallback((id: string): News | undefined => {
    return news[id];
  }, [news]);

  const getAllNews = useCallback((): News[] => {
    return Object.values(news).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [news]);

  const getPublishedNews = useCallback((): News[] => {
    return Object.values(news)
      .filter(n => n.status === 'published')
      .sort((a, b) => new Date(b.publishedAt || b.createdAt).getTime() - new Date(a.publishedAt || a.createdAt).getTime());
  }, [news]);

  const getNewsByType = useCallback((type: NewsType): News[] => {
    return Object.values(news)
      .filter(n => n.type === type && n.status === 'published')
      .sort((a, b) => new Date(b.publishedAt || b.createdAt).getTime() - new Date(a.publishedAt || a.createdAt).getTime());
  }, [news]);

  const getNewsByTag = useCallback((tag: string): News[] => {
    return Object.values(news)
      .filter(n => n.tags.includes(tag) && n.status === 'published')
      .sort((a, b) => new Date(b.publishedAt || b.createdAt).getTime() - new Date(a.publishedAt || a.createdAt).getTime());
  }, [news]);

  // Transfer operations
  const addTransfer = useCallback((transferData: Omit<Transfer, 'id' | 'createdAt'>): string => {
    const id = generateId();
    const newTransfer: Transfer = {
      ...transferData,
      id,
      createdAt: now(),
    };
    
    setTransfers(prev => ({ ...prev, [id]: newTransfer }));
    return id;
  }, []);

  const updateTransfer = useCallback((id: string, updates: Partial<Transfer>): boolean => {
    setTransfers(prev => {
      const item = prev[id];
      if (!item) return prev;
      
      return {
        ...prev,
        [id]: { ...item, ...updates },
      };
    });
    return true;
  }, []);

  const deleteTransfer = useCallback((id: string): boolean => {
    setTransfers(prev => {
      const { [id]: _, ...rest } = prev;
      return rest;
    });
    return true;
  }, []);

  const getTransferById = useCallback((id: string): Transfer | undefined => {
    return transfers[id];
  }, [transfers]);

  const getAllTransfers = useCallback((): Transfer[] => {
    return Object.values(transfers).sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }, [transfers]);

  const getTransfersByStatus = useCallback((status: Transfer['status']): Transfer[] => {
    return Object.values(transfers)
      .filter(t => t.status === status)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transfers]);

  const getTransfersByPlayer = useCallback((playerId: string): Transfer[] => {
    return Object.values(transfers)
      .filter(t => t.playerId === playerId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transfers]);

  const getTransfersByTeam = useCallback((teamId: string): Transfer[] => {
    return Object.values(transfers)
      .filter(t => t.fromTeamId === teamId || t.toTeamId === teamId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [transfers]);

  // Stats
  const getNewsStats = useCallback(() => {
    const allNews = Object.values(news);
    return {
      total: allNews.length,
      published: allNews.filter(n => n.status === 'published').length,
      draft: allNews.filter(n => n.status === 'draft').length,
      byType: {
        news: allNews.filter(n => n.type === 'news').length,
        transfer: allNews.filter(n => n.type === 'transfer').length,
        rumor: allNews.filter(n => n.type === 'rumor').length,
        announcement: allNews.filter(n => n.type === 'announcement').length,
      },
    };
  }, [news]);

  return {
    // News
    news: getAllNews(),
    publishedNews: getPublishedNews(),
    addNews,
    updateNews,
    deleteNews,
    publishNews,
    getNewsById,
    getNewsByType,
    getNewsByTag,
    
    // Transfers
    transfers: getAllTransfers(),
    addTransfer,
    updateTransfer,
    deleteTransfer,
    getTransferById,
    getTransfersByStatus,
    getTransfersByPlayer,
    getTransfersByTeam,
    
    // Stats
    getNewsStats,
    
    isLoaded,
  };
};

export default useNews;
