import { useState, useEffect, useCallback } from 'react';
import type { User, UserRole } from '@/types';

const AUTH_STORAGE_KEY = 'ctstats-auth';
const USERS_STORAGE_KEY = 'ctstats-users';

// Hash simple para contraseñas (en producción usar bcrypt)
const hashPassword = (password: string): string => {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(16);
};

// Usuario admin por defecto
const DEFAULT_ADMIN: User = {
  id: 'admin-001',
  username: 'admin',
  email: 'admin@ctstats.gg',
  passwordHash: hashPassword('admin123'),
  role: 'admin',
  displayName: 'Administrador',
  createdAt: new Date().toISOString(),
};

// Usuarios por defecto
const DEFAULT_USERS: Record<string, User> = {
  [DEFAULT_ADMIN.id]: DEFAULT_ADMIN,
};

interface AuthState {
  currentUser: User | null;
  isAuthenticated: boolean;
}

export const useAuth = () => {
  const [state, setState] = useState<AuthState>({
    currentUser: null,
    isAuthenticated: false,
  });
  const [isLoaded, setIsLoaded] = useState(false);

  // Cargar usuarios y sesión
  useEffect(() => {
    // Inicializar usuarios por defecto si no existen
    const storedUsers = localStorage.getItem(USERS_STORAGE_KEY);
    if (!storedUsers) {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(DEFAULT_USERS));
    }

    // Cargar sesión actual
    const storedAuth = localStorage.getItem(AUTH_STORAGE_KEY);
    if (storedAuth) {
      try {
        const parsed = JSON.parse(storedAuth);
        setState(parsed);
      } catch (e) {
        console.error('Error loading auth:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Guardar sesión
  useEffect(() => {
    if (isLoaded) {
      if (state.currentUser) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(state));
      } else {
        localStorage.removeItem(AUTH_STORAGE_KEY);
      }
    }
  }, [state, isLoaded]);

  const getUsers = useCallback((): Record<string, User> => {
    const stored = localStorage.getItem(USERS_STORAGE_KEY);
    return stored ? JSON.parse(stored) : DEFAULT_USERS;
  }, []);

  const saveUsers = useCallback((users: Record<string, User>) => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  }, []);

  const login = useCallback((usernameOrEmail: string, password: string): boolean => {
    const users = getUsers();
    const passwordHash = hashPassword(password);
    
    const user = Object.values(users).find(
      u => (u.username === usernameOrEmail || u.email === usernameOrEmail) && u.passwordHash === passwordHash
    );

    if (user) {
      // Actualizar último login
      const updatedUser = { ...user, lastLogin: new Date().toISOString() };
      users[user.id] = updatedUser;
      saveUsers(users);

      setState({
        currentUser: updatedUser,
        isAuthenticated: true,
      });
      return true;
    }
    return false;
  }, [getUsers, saveUsers]);

  const register = useCallback((username: string, email: string, password: string, displayName?: string): { success: boolean; error?: string } => {
    const users = getUsers();
    
    // Validar que no exista
    if (Object.values(users).some(u => u.username === username)) {
      return { success: false, error: 'El nombre de usuario ya existe' };
    }
    if (Object.values(users).some(u => u.email === email)) {
      return { success: false, error: 'El email ya está registrado' };
    }

    const newUser: User = {
      id: `user-${Date.now()}`,
      username,
      email,
      passwordHash: hashPassword(password),
      role: 'viewer',
      displayName: displayName || username,
      createdAt: new Date().toISOString(),
    };

    users[newUser.id] = newUser;
    saveUsers(users);

    return { success: true };
  }, [getUsers, saveUsers]);

  const logout = useCallback(() => {
    setState({
      currentUser: null,
      isAuthenticated: false,
    });
  }, []);

  const hasRole = useCallback((roles: UserRole[]): boolean => {
    return state.currentUser ? roles.includes(state.currentUser.role) : false;
  }, [state.currentUser]);

  const isAdmin = useCallback((): boolean => {
    return state.currentUser?.role === 'admin';
  }, [state.currentUser]);

  const isEditor = useCallback((): boolean => {
    return state.currentUser?.role === 'admin' || state.currentUser?.role === 'editor';
  }, [state.currentUser]);

  const updateUser = useCallback((userId: string, updates: Partial<User>): boolean => {
    const users = getUsers();
    if (!users[userId]) return false;

    users[userId] = { ...users[userId], ...updates };
    saveUsers(users);

    // Si es el usuario actual, actualizar estado
    if (state.currentUser?.id === userId) {
      setState(prev => ({
        ...prev,
        currentUser: users[userId],
      }));
    }
    return true;
  }, [getUsers, saveUsers, state.currentUser]);

  const changePassword = useCallback((userId: string, oldPassword: string, newPassword: string): boolean => {
    const users = getUsers();
    const user = users[userId];
    if (!user) return false;

    if (user.passwordHash !== hashPassword(oldPassword)) {
      return false;
    }

    users[userId] = { ...user, passwordHash: hashPassword(newPassword) };
    saveUsers(users);
    return true;
  }, [getUsers, saveUsers]);

  const getAllUsers = useCallback((): User[] => {
    return Object.values(getUsers());
  }, [getUsers]);

  return {
    ...state,
    isLoaded,
    login,
    logout,
    register,
    hasRole,
    isAdmin,
    isEditor,
    updateUser,
    changePassword,
    getAllUsers,
    currentUser: state.currentUser,
  };
};

export default useAuth;
