import { useState, useEffect, useCallback } from 'react';
import type { 
  AppState, 
  Player, 
  Team, 
  Match, 
  Event, 
  Ranking, 
  TierType,
  SystemConfig,
  PlayerStats
} from '@/types';

const defaultConfig: SystemConfig = {
  version: '1.0.0',
  lastUpdated: new Date().toISOString(),
  ratingWeights: {
    acs: 0.25,
    kd: 0.20,
    adr: 0.20,
    kast: 0.15,
    fkfd: 0.10,
    winBonus: 0.10,
    tierMultiplier: {
      'LR': 1.5,
      'DIV 1': 1.3,
      'DIV 2': 1.1,
      'LRF': 1.5,
      'GC': 1.2,
      'Paradas': 1.0,
      'Torneo Comunitario': 0.8,
      'Torneos AM': 0.6,
    }
  },
  rankingPoints: {
    win: 10,
    loss: -5,
    tournamentWin: 100,
    tournamentTop4: 50,
    tierMultiplier: {
      'LR': 3.0,
      'DIV 1': 2.5,
      'DIV 2': 2.0,
      'LRF': 3.0,
      'GC': 2.0,
      'Paradas': 1.5,
      'Torneo Comunitario': 1.0,
      'Torneos AM': 0.5,
    }
  }
};

const defaultState: AppState = {
  players: {},
  teams: {},
  matches: {},
  events: {},
  rankings: {},
  config: defaultConfig
};

const STORAGE_KEY = 'vlr-espana-data';

export const generateId = () => Math.random().toString(36).substring(2, 15);
export const now = () => new Date().toISOString();

export const calculatePlayerRating = (stats: PlayerStats, tier: TierType, config: SystemConfig): number => {
  const { ratingWeights } = config;
  
  const normalizedACS = Math.min(stats.acs / 300, 1);
  const normalizedKD = Math.min(Math.max(stats.kd, 0) / 2, 1);
  const normalizedADR = Math.min(stats.adr / 200, 1);
  const normalizedKAST = stats.kast / 100;
  const normalizedFKFD = Math.min(Math.max(stats.fkfd, 0) / 2, 1);
  const winRate = stats.matchesPlayed > 0 ? stats.wins / stats.matchesPlayed : 0;
  
  let rating = (
    normalizedACS * ratingWeights.acs +
    normalizedKD * ratingWeights.kd +
    normalizedADR * ratingWeights.adr +
    normalizedKAST * ratingWeights.kast +
    normalizedFKFD * ratingWeights.fkfd +
    winRate * ratingWeights.winBonus
  ) * 100;
  
  rating *= ratingWeights.tierMultiplier[tier] || 1;
  
  return Math.round(rating * 10) / 10;
};

export const calculateRankingPoints = (
  team: Team, 
  matches: Match[], 
  events: Event[],
  config: SystemConfig
): number => {
  const { rankingPoints } = config;
  const tierMultiplier = rankingPoints.tierMultiplier[team.tier] || 1;
  
  let points = 0;
  
  const teamMatches = matches.filter(m => 
    (m.teamAId === team.id || m.teamBId === team.id) && m.status === 'completed'
  );
  
  teamMatches.forEach(match => {
    const won = (match.teamAId === team.id && match.teamAScore > match.teamBScore) ||
                (match.teamBId === team.id && match.teamBScore > match.teamAScore);
    points += won ? rankingPoints.win : rankingPoints.loss;
  });
  
  const teamEvents = events.filter(e => e.teams.includes(team.id) && e.status === 'completed');
  teamEvents.forEach(event => {
    const eventMatches = matches.filter(m => m.eventId === event.id && (m.teamAId === team.id || m.teamBId === team.id));
    const wins = eventMatches.filter(m => 
      (m.teamAId === team.id && m.teamAScore > m.teamBScore) ||
      (m.teamBId === team.id && m.teamBScore > m.teamAScore)
    ).length;
    
    if (wins >= eventMatches.length * 0.7) {
      points += rankingPoints.tournamentWin;
    } else if (wins >= eventMatches.length * 0.5) {
      points += rankingPoints.tournamentTop4;
    }
  });
  
  return Math.round(points * tierMultiplier);
};

// Global state for non-hook access
let globalState: AppState = defaultState;

export const useStore = () => {
  const [state, setState] = useState<AppState>(defaultState);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        globalState = { ...defaultState, ...parsed };
        setState(globalState);
      } catch (e) {
        console.error('Error loading data:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
      globalState = state;
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }
  }, [state, isLoaded]);

  const addPlayer = useCallback((playerData: Omit<Player, 'id' | 'createdAt' | 'updatedAt' | 'rating' | 'peakRating'>) => {
    const id = generateId();
    const tier = playerData.teamId ? state.teams[playerData.teamId]?.tier : 'LR';
    const rating = calculatePlayerRating(playerData.stats, tier || 'LR', state.config);
    const newPlayer: Player = {
      ...playerData,
      id,
      rating,
      peakRating: rating,
      createdAt: now(),
      updatedAt: now()
    };
    
    setState(prev => ({
      ...prev,
      players: { ...prev.players, [id]: newPlayer }
    }));
    
    return id;
  }, [state.config, state.teams]);

  const updatePlayer = useCallback((id: string, updates: Partial<Player>) => {
    setState(prev => {
      const player = prev.players[id];
      if (!player) return prev;
      
      const updatedStats = updates.stats || player.stats;
      const tier = updates.teamId ? prev.teams[updates.teamId]?.tier : player.teamId ? prev.teams[player.teamId]?.tier : 'LR';
      const newRating = calculatePlayerRating(updatedStats, tier || 'LR', prev.config);
      
      const updatedPlayer: Player = {
        ...player,
        ...updates,
        rating: newRating,
        peakRating: Math.max(newRating, player.peakRating),
        updatedAt: now()
      };
      
      return {
        ...prev,
        players: { ...prev.players, [id]: updatedPlayer }
      };
    });
  }, []);

  const deletePlayer = useCallback((id: string) => {
    setState(prev => {
      const { [id]: _, ...rest } = prev.players;
      return { ...prev, players: rest };
    });
  }, []);

  const addTeam = useCallback((teamData: Omit<Team, 'id' | 'createdAt' | 'updatedAt' | 'rating'>) => {
    const id = generateId();
    const newTeam: Team = {
      ...teamData,
      id,
      rating: 1000,
      createdAt: now(),
      updatedAt: now()
    };
    
    setState(prev => ({
      ...prev,
      teams: { ...prev.teams, [id]: newTeam }
    }));
    
    return id;
  }, []);

  const updateTeam = useCallback((id: string, updates: Partial<Team>) => {
    setState(prev => {
      const team = prev.teams[id];
      if (!team) return prev;
      
      const updatedTeam: Team = {
        ...team,
        ...updates,
        updatedAt: now()
      };
      
      return {
        ...prev,
        teams: { ...prev.teams, [id]: updatedTeam }
      };
    });
  }, []);

  const deleteTeam = useCallback((id: string) => {
    setState(prev => {
      const { [id]: _, ...rest } = prev.teams;
      return { ...prev, teams: rest };
    });
  }, []);

  const addEvent = useCallback((eventData: Omit<Event, 'id' | 'createdAt' | 'updatedAt'>) => {
    const id = generateId();
    const newEvent: Event = {
      ...eventData,
      id,
      createdAt: now(),
      updatedAt: now()
    };
    
    setState(prev => ({
      ...prev,
      events: { ...prev.events, [id]: newEvent }
    }));
    
    return id;
  }, []);

  const updateEvent = useCallback((id: string, updates: Partial<Event>) => {
    setState(prev => {
      const event = prev.events[id];
      if (!event) return prev;
      
      const updatedEvent: Event = {
        ...event,
        ...updates,
        updatedAt: now()
      };
      
      return {
        ...prev,
        events: { ...prev.events, [id]: updatedEvent }
      };
    });
  }, []);

  const deleteEvent = useCallback((id: string) => {
    setState(prev => {
      const { [id]: _, ...rest } = prev.events;
      return { ...prev, events: rest };
    });
  }, []);

  const addMatch = useCallback((matchData: Omit<Match, 'id' | 'createdAt' | 'updatedAt'>) => {
    const id = generateId();
    const newMatch: Match = {
      ...matchData,
      id,
      createdAt: now(),
      updatedAt: now()
    };
    
    setState(prev => ({
      ...prev,
      matches: { ...prev.matches, [id]: newMatch }
    }));
    
    return id;
  }, []);

  const updateMatch = useCallback((id: string, updates: Partial<Match>) => {
    setState(prev => {
      const match = prev.matches[id];
      if (!match) return prev;
      
      const updatedMatch: Match = {
        ...match,
        ...updates,
        updatedAt: now()
      };
      
      if (updates.status === 'completed' && match.status !== 'completed') {
        updatedMatch.completedAt = now();
      }
      
      return {
        ...prev,
        matches: { ...prev.matches, [id]: updatedMatch }
      };
    });
  }, []);

  const deleteMatch = useCallback((id: string) => {
    setState(prev => {
      const { [id]: _, ...rest } = prev.matches;
      return { ...prev, matches: rest };
    });
  }, []);

  const recalculateRankings = useCallback(() => {
    setState(prev => {
      const rankings: Record<string, Ranking> = {};
      
      Object.values(prev.teams).forEach(team => {
        const points = calculateRankingPoints(team, Object.values(prev.matches), Object.values(prev.events), prev.config);
        rankings[team.id] = {
          teamId: team.id,
          rank: 0,
          previousRank: prev.rankings[team.id]?.rank || 0,
          points,
          tier: team.tier,
          gender: team.gender,
          matchesPlayed: team.stats.matchesPlayed,
          wins: team.stats.wins,
          losses: team.stats.losses,
          winRate: team.stats.matchesPlayed > 0 ? team.stats.wins / team.stats.matchesPlayed : 0,
          tournamentPoints: 0,
          matchPoints: points,
          recentFormPoints: 0
        };
      });
      
      const sortedRankings = Object.values(rankings).sort((a, b) => b.points - a.points);
      sortedRankings.forEach((ranking, index) => {
        rankings[ranking.teamId].rank = index + 1;
      });
      
      return {
        ...prev,
        rankings
      };
    });
  }, []);

  const resetData = useCallback(() => {
    setState(defaultState);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const exportData = useCallback(() => {
    return JSON.stringify(state, null, 2);
  }, [state]);

  const importData = useCallback((jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      setState({ ...defaultState, ...data });
      return true;
    } catch (e) {
      console.error('Error importing data:', e);
      return false;
    }
  }, []);

  const getPlayer = useCallback((id: string) => state.players[id], [state.players]);
  const getTeam = useCallback((id: string) => state.teams[id], [state.teams]);
  const getEvent = useCallback((id: string) => state.events[id], [state.events]);
  const getMatch = useCallback((id: string) => state.matches[id], [state.matches]);

  return {
    state,
    isLoaded,
    players: Object.values(state.players),
    teams: Object.values(state.teams),
    events: Object.values(state.events),
    matches: Object.values(state.matches),
    rankings: Object.values(state.rankings),
    addPlayer,
    updatePlayer,
    deletePlayer,
    getPlayer,
    addTeam,
    updateTeam,
    deleteTeam,
    getTeam,
    addEvent,
    updateEvent,
    deleteEvent,
    getEvent,
    addMatch,
    updateMatch,
    deleteMatch,
    getMatch,
    recalculateRankings,
    resetData,
    exportData,
    importData
  };
};

// Export global state accessor for non-component usage
export const getGlobalState = () => globalState;

export default useStore;
