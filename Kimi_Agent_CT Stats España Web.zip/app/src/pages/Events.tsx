import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Trophy, Calendar, Users, MapPin, DollarSign, Search, ChevronRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/store/useStore';
import { TIERS, type Gender, type TierType, type EventStatus } from '@/types';

function EventCard({ event }: { event: any }) {
  const tier = TIERS.find(t => t.id === event.tier);
  const statusColors: Record<string, string> = { upcoming: 'bg-blue-500/20 text-blue-400', ongoing: 'bg-green-500/20 text-green-400', completed: 'bg-gray-500/20 text-gray-400' };
  const statusLabels: Record<string, string> = { upcoming: 'Próximo', ongoing: 'En curso', completed: 'Finalizado' };

  return (
    <Link to={`/event/${event.id}`}>
      <Card className="bg-[#1a202c] border-[#2d3748] hover:border-[#ff4655] transition-colors h-full">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <Badge variant="outline" className="text-xs" style={{ borderColor: tier?.color, color: tier?.color }}>{tier?.name}</Badge>
            <span className={`text-xs px-2 py-1 rounded ${statusColors[event.status]}`}>{statusLabels[event.status]}</span>
          </div>
          <h3 className="font-bold text-white text-lg mb-2">{event.name}</h3>
          <div className="space-y-2 mb-4">
            <div className="flex items-center gap-2 text-gray-400 text-sm"><Calendar className="w-4 h-4" />{new Date(event.startDate).toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })} - {new Date(event.endDate).toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}</div>
            {event.location && <div className="flex items-center gap-2 text-gray-400 text-sm"><MapPin className="w-4 h-4" />{event.location}</div>}
            {event.prizePool && <div className="flex items-center gap-2 text-gray-400 text-sm"><DollarSign className="w-4 h-4" />{event.prizePool}</div>}
          </div>
          <div className="flex items-center justify-between pt-4 border-t border-[#2d3748]">
            <div className="flex items-center gap-2 text-gray-400 text-sm"><Users className="w-4 h-4" />{event.teams.length} equipos</div>
            <ChevronRight className="w-5 h-5 text-gray-500" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export function Events() {
  const { events } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGender, setSelectedGender] = useState<Gender | 'all'>('all');
  const [selectedTier, setSelectedTier] = useState<TierType | 'all'>('all');
  const [activeTab, setActiveTab] = useState<EventStatus | 'all'>('all');

  const filteredEvents = useMemo(() => {
    let filtered = [...events];
    if (activeTab !== 'all') filtered = filtered.filter(e => e.status === activeTab);
    if (searchQuery) filtered = filtered.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()));
    if (selectedGender !== 'all') filtered = filtered.filter(e => e.gender === selectedGender);
    if (selectedTier !== 'all') filtered = filtered.filter(e => e.tier === selectedTier);
    return filtered.sort((a, b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime());
  }, [events, activeTab, searchQuery, selectedGender, selectedTier]);

  const eventCounts = useMemo(() => ({ all: events.length, upcoming: events.filter(e => e.status === 'upcoming').length, ongoing: events.filter(e => e.status === 'ongoing').length, completed: events.filter(e => e.status === 'completed').length }), [events]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3"><Trophy className="w-8 h-8 text-[#ff4655]" />Eventos</h1>
          <p className="text-gray-400 mt-1">Todos los torneos y competiciones</p>
        </div>
      </div>

      <Card className="bg-[#1a202c] border-[#2d3748]">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Buscar eventos..." className="pl-10 bg-[#0f1419] border-[#2d3748] text-white" />
            </div>
            <Select value={selectedGender} onValueChange={(v) => setSelectedGender(v as Gender | 'all')}>
              <SelectTrigger className="w-full md:w-40 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Género" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="masculino">Masculino</SelectItem>
                <SelectItem value="femenino">Femenino</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedTier} onValueChange={(v) => setSelectedTier(v as TierType | 'all')}>
              <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Liga" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todas las ligas</SelectItem>
                {TIERS.map(tier => <SelectItem key={tier.id} value={tier.id}>{tier.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as EventStatus | 'all')}>
        <TabsList className="bg-[#1a202c] border border-[#2d3748]">
          <TabsTrigger value="all" className="data-[state=active]:bg-[#ff4655]">Todos ({eventCounts.all})</TabsTrigger>
          <TabsTrigger value="ongoing" className="data-[state=active]:bg-green-500">En curso ({eventCounts.ongoing})</TabsTrigger>
          <TabsTrigger value="upcoming" className="data-[state=active]:bg-blue-500">Próximos ({eventCounts.upcoming})</TabsTrigger>
          <TabsTrigger value="completed" className="data-[state=active]:bg-gray-500">Finalizados ({eventCounts.completed})</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredEvents.length > 0 ? filteredEvents.map(event => <EventCard key={event.id} event={event} />) : <div className="col-span-full text-center py-16 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]"><Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" /><p className="text-lg">No se encontraron eventos</p></div>}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
