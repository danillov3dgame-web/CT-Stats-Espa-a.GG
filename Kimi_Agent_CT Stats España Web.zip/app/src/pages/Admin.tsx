import { useState } from 'react';
import { Plus, Users, Shield, Trophy, Target, Download, Upload, Trash2, RefreshCw, Database } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/store/useStore';
import { TIERS, ROLES, type Gender, type TierType, type EventType, type MatchStatus, type PlayerRole } from '@/types';

function CreatePlayerForm({ onSuccess }: { onSuccess: () => void }) {
  const { addPlayer, teams } = useStore();
  const [name, setName] = useState('');
  const [role, setRole] = useState<PlayerRole>('');
  const [teamId, setTeamId] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    addPlayer({ name, role: role || undefined, teamId: teamId || undefined, stats: { acs: 0, kd: 0, adr: 0, kast: 0, fb: 0, fd: 0, fkfd: 0, roundsPlayed: 0, matchesPlayed: 0, wins: 0, losses: 0, kills: 0, deaths: 0, assists: 0, headshotPercentage: 0, clutches: 0, clutchesWon: 0 } });
    onSuccess();
    setName(''); setRole(''); setTeamId('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div><Label>Nombre del jugador</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: TenZ" /></div>
      <div><Label>Rol</Label><Select value={role} onValueChange={(v) => setRole(v as PlayerRole)}><SelectTrigger><SelectValue placeholder="Seleccionar rol" /></SelectTrigger><SelectContent>{ROLES.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent></Select></div>
      <div><Label>Equipo (opcional)</Label><Select value={teamId} onValueChange={setTeamId}><SelectTrigger><SelectValue placeholder="Seleccionar equipo" /></SelectTrigger><SelectContent><SelectItem value="">Sin equipo</SelectItem>{teams.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent></Select></div>
      <Button type="submit" className="w-full bg-[#ff4655] hover:bg-[#ff4655]/90">Crear Jugador</Button>
    </form>
  );
}

function CreateTeamForm({ onSuccess }: { onSuccess: () => void }) {
  const { addTeam } = useStore();
  const [name, setName] = useState('');
  const [shortName, setShortName] = useState('');
  const [tier, setTier] = useState<TierType>('LR');
  const [gender, _setGender] = useState<Gender>('masculino');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    addTeam({ name, shortName: shortName || undefined, tier, gender, players: [], stats: { matchesPlayed: 0, wins: 0, losses: 0, roundsWon: 0, roundsLost: 0, tournamentWins: 0, tournamentTop4: 0, recentForm: [] } });
    onSuccess();
    setName(''); setShortName('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div><Label>Nombre del equipo</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: Team Heretics" /></div>
      <div><Label>Nombre corto (opcional)</Label><Input value={shortName} onChange={(e) => setShortName(e.target.value)} placeholder="Ej: TH" /></div>
      <div><Label>Liga/Tier</Label><Select value={tier} onValueChange={(v) => setTier(v as TierType)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{TIERS.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent></Select></div>
      <div><Label>Género</Label><Select value={gender} onValueChange={(v) => _setGender(v as Gender)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="masculino">Masculino</SelectItem><SelectItem value="femenino">Femenino</SelectItem><SelectItem value="torneo">Torneo</SelectItem></SelectContent></Select></div>
      <Button type="submit" className="w-full bg-[#ff4655] hover:bg-[#ff4655]/90">Crear Equipo</Button>
    </form>
  );
}

function CreateEventForm({ onSuccess }: { onSuccess: () => void }) {
  const { addEvent } = useStore();
  const [name, setName] = useState('');
  const [shortName, setShortName] = useState('');
  const [tier, setTier] = useState<TierType>('LR');
  const [gender, _setGender] = useState<Gender>('masculino');
  const [type, setType] = useState<EventType>('league');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [prizePool, setPrizePool] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !startDate || !endDate) return;
    addEvent({ name, shortName: shortName || undefined, tier, gender, type, startDate, endDate, prizePool: prizePool || undefined, status: 'upcoming', teams: [], matches: [] });
    onSuccess();
    setName(''); setShortName(''); setStartDate(''); setEndDate(''); setPrizePool('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div><Label>Nombre del evento</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej: Liga Radiante 2024" /></div>
      <div><Label>Nombre corto (opcional)</Label><Input value={shortName} onChange={(e) => setShortName(e.target.value)} placeholder="Ej: LR 2024" /></div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label>Liga/Tier</Label><Select value={tier} onValueChange={(v) => setTier(v as TierType)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{TIERS.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Tipo</Label><Select value={type} onValueChange={(v) => setType(v as EventType)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="league">Liga</SelectItem><SelectItem value="tournament">Torneo</SelectItem><SelectItem value="lan">LAN</SelectItem></SelectContent></Select></div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label>Fecha inicio</Label><Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} /></div>
        <div><Label>Fecha fin</Label><Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} /></div>
      </div>
      <div><Label>Prize Pool (opcional)</Label><Input value={prizePool} onChange={(e) => setPrizePool(e.target.value)} placeholder="Ej: €10,000" /></div>
      <Button type="submit" className="w-full bg-[#ff4655] hover:bg-[#ff4655]/90">Crear Evento</Button>
    </form>
  );
}

function CreateMatchForm({ onSuccess }: { onSuccess: () => void }) {
  const { addMatch, teams, events } = useStore();
  const [eventId, setEventId] = useState('');
  const [tier, setTier] = useState<TierType>('LR');
  const [teamAId, setTeamAId] = useState('');
  const [teamBId, setTeamBId] = useState('');
  const [scheduledAt, setScheduledAt] = useState('');
  const [status, setStatus] = useState<MatchStatus>('upcoming');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventId || !teamAId || !teamBId || !scheduledAt) return;
    if (teamAId === teamBId) { alert('Los equipos deben ser diferentes'); return; }
    addMatch({ eventId, tier, gender: 'masculino', teamAId, teamBId, teamAScore: 0, teamBScore: 0, maps: [], status, scheduledAt });
    onSuccess();
    setEventId(''); setTeamAId(''); setTeamBId(''); setScheduledAt('');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div><Label>Evento</Label><Select value={eventId} onValueChange={setEventId}><SelectTrigger><SelectValue placeholder="Seleccionar evento" /></SelectTrigger><SelectContent>{events.map(e => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}</SelectContent></Select></div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label>Liga/Tier</Label><Select value={tier} onValueChange={(v) => setTier(v as TierType)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{TIERS.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Estado</Label><Select value={status} onValueChange={(v) => setStatus(v as MatchStatus)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="upcoming">Próximo</SelectItem><SelectItem value="live">En vivo</SelectItem><SelectItem value="completed">Finalizado</SelectItem></SelectContent></Select></div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label>Equipo A</Label><Select value={teamAId} onValueChange={setTeamAId}><SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger><SelectContent>{teams.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent></Select></div>
        <div><Label>Equipo B</Label><Select value={teamBId} onValueChange={setTeamBId}><SelectTrigger><SelectValue placeholder="Seleccionar" /></SelectTrigger><SelectContent>{teams.map(t => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}</SelectContent></Select></div>
      </div>
      <div><Label>Fecha y hora</Label><Input type="datetime-local" value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} /></div>
      <Button type="submit" className="w-full bg-[#ff4655] hover:bg-[#ff4655]/90">Crear Partido</Button>
    </form>
  );
}

export function Admin() {
  const { players, teams, events, matches, resetData, exportData, importData, recalculateRankings, deletePlayer, deleteTeam } = useStore();
  const [importText, setImportText] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState<'player' | 'team' | 'event' | 'match'>('player');

  const openDialog = (type: typeof dialogType) => { setDialogType(type); setDialogOpen(true); };

  const handleImport = () => { if (importData(importText)) { alert('Datos importados correctamente'); setImportText(''); } else { alert('Error al importar datos'); } };

  const handleExport = () => {
    const data = exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vlr-espana-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white flex items-center gap-3"><Database className="w-8 h-8 text-[#ff4655]" />Panel de Administración</h1>
        <p className="text-gray-400 mt-1">Gestiona equipos, jugadores, eventos y partidos</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-[#1a202c] border-[#2d3748]"><CardContent className="p-4"><div className="flex items-center gap-3"><Users className="w-8 h-8 text-[#ff4655]" /><div><p className="text-2xl font-bold text-white">{players.length}</p><p className="text-xs text-gray-400">Jugadores</p></div></div></CardContent></Card>
        <Card className="bg-[#1a202c] border-[#2d3748]"><CardContent className="p-4"><div className="flex items-center gap-3"><Shield className="w-8 h-8 text-[#ff4655]" /><div><p className="text-2xl font-bold text-white">{teams.length}</p><p className="text-xs text-gray-400">Equipos</p></div></div></CardContent></Card>
        <Card className="bg-[#1a202c] border-[#2d3748]"><CardContent className="p-4"><div className="flex items-center gap-3"><Trophy className="w-8 h-8 text-[#ff4655]" /><div><p className="text-2xl font-bold text-white">{events.length}</p><p className="text-xs text-gray-400">Eventos</p></div></div></CardContent></Card>
        <Card className="bg-[#1a202c] border-[#2d3748]"><CardContent className="p-4"><div className="flex items-center gap-3"><Target className="w-8 h-8 text-[#ff4655]" /><div><p className="text-2xl font-bold text-white">{matches.length}</p><p className="text-xs text-gray-400">Partidos</p></div></div></CardContent></Card>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Dialog open={dialogOpen && dialogType === 'player'} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild><Button onClick={() => openDialog('player')} className="h-auto py-4 bg-[#ff4655] hover:bg-[#ff4655]/90"><Plus className="w-5 h-5 mr-2" /><div className="text-left"><p className="font-semibold">Crear Jugador</p><p className="text-xs opacity-80">Añadir nuevo jugador</p></div></Button></DialogTrigger>
          <DialogContent className="bg-[#1a202c] border-[#2d3748]"><DialogHeader><DialogTitle className="text-white">Crear Jugador</DialogTitle></DialogHeader><CreatePlayerForm onSuccess={() => setDialogOpen(false)} /></DialogContent>
        </Dialog>
        <Dialog open={dialogOpen && dialogType === 'team'} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild><Button onClick={() => openDialog('team')} className="h-auto py-4 bg-[#ff4655] hover:bg-[#ff4655]/90"><Plus className="w-5 h-5 mr-2" /><div className="text-left"><p className="font-semibold">Crear Equipo</p><p className="text-xs opacity-80">Añadir nuevo equipo</p></div></Button></DialogTrigger>
          <DialogContent className="bg-[#1a202c] border-[#2d3748]"><DialogHeader><DialogTitle className="text-white">Crear Equipo</DialogTitle></DialogHeader><CreateTeamForm onSuccess={() => setDialogOpen(false)} /></DialogContent>
        </Dialog>
        <Dialog open={dialogOpen && dialogType === 'event'} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild><Button onClick={() => openDialog('event')} className="h-auto py-4 bg-[#ff4655] hover:bg-[#ff4655]/90"><Plus className="w-5 h-5 mr-2" /><div className="text-left"><p className="font-semibold">Crear Evento</p><p className="text-xs opacity-80">Añadir nuevo evento</p></div></Button></DialogTrigger>
          <DialogContent className="bg-[#1a202c] border-[#2d3748]"><DialogHeader><DialogTitle className="text-white">Crear Evento</DialogTitle></DialogHeader><CreateEventForm onSuccess={() => setDialogOpen(false)} /></DialogContent>
        </Dialog>
        <Dialog open={dialogOpen && dialogType === 'match'} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild><Button onClick={() => openDialog('match')} className="h-auto py-4 bg-[#ff4655] hover:bg-[#ff4655]/90"><Plus className="w-5 h-5 mr-2" /><div className="text-left"><p className="font-semibold">Crear Partido</p><p className="text-xs opacity-80">Programar nuevo partido</p></div></Button></DialogTrigger>
          <DialogContent className="bg-[#1a202c] border-[#2d3748] max-w-lg"><DialogHeader><DialogTitle className="text-white">Crear Partido</DialogTitle></DialogHeader><CreateMatchForm onSuccess={() => setDialogOpen(false)} /></DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="manage">
        <TabsList className="bg-[#1a202c] border border-[#2d3748]">
          <TabsTrigger value="manage" className="data-[state=active]:bg-[#ff4655]">Gestionar Datos</TabsTrigger>
          <TabsTrigger value="backup" className="data-[state=active]:bg-[#ff4655]">Backup/Restore</TabsTrigger>
        </TabsList>

        <TabsContent value="manage" className="mt-6 space-y-6">
          <Card className="bg-[#1a202c] border-[#2d3748]">
            <CardHeader><CardTitle className="text-white">Equipos</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {teams.map(team => (
                  <div key={team.id} className="flex items-center justify-between p-3 bg-[#0f1419] rounded">
                    <div className="flex items-center gap-3"><div className="w-8 h-8 bg-[#2d3748] rounded flex items-center justify-center">{team.shortName?.charAt(0) || team.name.charAt(0)}</div><span className="text-white">{team.name}</span><Badge variant="outline" className="text-xs">{team.players.length} jugadores</Badge></div>
                    <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => deleteTeam(team.id)}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[#1a202c] border-[#2d3748]">
            <CardHeader><CardTitle className="text-white">Jugadores</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {players.map(player => (
                  <div key={player.id} className="flex items-center justify-between p-3 bg-[#0f1419] rounded">
                    <div className="flex items-center gap-3"><div className="w-8 h-8 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded flex items-center justify-center text-sm font-bold text-white">{player.name.charAt(0)}</div><span className="text-white">{player.name}</span>{player.role && <Badge variant="outline" className="text-xs">{player.role}</Badge>}<span className="text-[#ff4655] font-semibold text-sm">{player.rating.toFixed(1)}</span></div>
                    <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-300 hover:bg-red-500/10" onClick={() => deletePlayer(player.id)}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup" className="mt-6 space-y-6">
          <Card className="bg-[#1a202c] border-[#2d3748]">
            <CardHeader><CardTitle className="text-white">Backup y Restore</CardTitle></CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-white font-semibold mb-2">Exportar Datos</h3>
                <p className="text-gray-400 text-sm mb-3">Descarga una copia de seguridad de todos los datos</p>
                <Button onClick={handleExport} variant="outline" className="border-[#ff4655] text-[#ff4655]"><Download className="w-4 h-4 mr-2" />Exportar JSON</Button>
              </div>
              <div className="border-t border-[#2d3748] pt-6">
                <h3 className="text-white font-semibold mb-2">Importar Datos</h3>
                <p className="text-gray-400 text-sm mb-3">Pega el contenido del archivo JSON para restaurar</p>
                <textarea value={importText} onChange={(e) => setImportText(e.target.value)} placeholder="Pega aquí el JSON..." className="w-full h-32 bg-[#0f1419] border border-[#2d3748] rounded-md p-3 text-white text-sm mb-3" />
                <Button onClick={handleImport} variant="outline" className="border-blue-500 text-blue-500"><Upload className="w-4 h-4 mr-2" />Importar</Button>
              </div>
              <div className="border-t border-[#2d3748] pt-6">
                <h3 className="text-white font-semibold mb-2">Recalcular Rankings</h3>
                <p className="text-gray-400 text-sm mb-3">Actualiza todos los rankings basándose en los datos actuales</p>
                <Button onClick={recalculateRankings} variant="outline" className="border-green-500 text-green-500"><RefreshCw className="w-4 h-4 mr-2" />Recalcular</Button>
              </div>
              <div className="border-t border-[#2d3748] pt-6">
                <h3 className="text-red-400 font-semibold mb-2">Zona Peligrosa</h3>
                <p className="text-gray-400 text-sm mb-3">Esta acción eliminará TODOS los datos permanentemente</p>
                <Button onClick={() => { if (confirm('¿Estás seguro? Esta acción no se puede deshacer.')) resetData(); }} variant="outline" className="border-red-500 text-red-500"><Trash2 className="w-4 h-4 mr-2" />Borrar Todo</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
