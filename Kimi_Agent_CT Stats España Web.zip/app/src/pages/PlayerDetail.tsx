import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Target, TrendingUp, Award, Users, Crosshair, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/store/useStore';
import { TIERS, ROLES } from '@/types';

const ROLE_ICONS: Record<string, any> = { 'Duelist': Crosshair, 'Initiator': Zap, 'Controller': Target, 'Sentinel': Award, 'Flex': Users, '': Users };

export function PlayerDetail() {
  const { id } = useParams<{ id: string }>();
  const { getPlayer, getTeam } = useStore();
  
  const player = id ? getPlayer(id) : null;
  
  if (!player) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400">Jugador no encontrado</p>
        <Link to="/players"><Button variant="outline" className="mt-4"><ArrowLeft className="w-4 h-4 mr-2" />Volver a jugadores</Button></Link>
      </div>
    );
  }

  const team = player.teamId ? getTeam(player.teamId) : null;
  const tier = team ? TIERS.find(t => t.id === team.tier) : null;
  const role = ROLES.find(r => r.value === (player.role || ''));
  const RoleIcon = ROLE_ICONS[player.role || ''] || Users;

  return (
    <div className="space-y-6">
      <Link to="/players"><Button variant="ghost" className="text-gray-400 hover:text-white"><ArrowLeft className="w-4 h-4 mr-2" />Volver a jugadores</Button></Link>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-24 h-24 md:w-32 md:h-32 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded-xl flex items-center justify-center text-4xl md:text-5xl font-bold text-white shrink-0">{player.name.charAt(0)}</div>
        
        <div className="flex-1">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{player.name}</h1>
          
          <div className="flex flex-wrap items-center gap-2 mb-4">
            {player.role && <Badge variant="outline" className="text-sm flex items-center gap-1" style={{ borderColor: role?.color, color: role?.color }}><RoleIcon className="w-3 h-3" />{role?.label}</Badge>}
            {tier && <Badge variant="outline" className="text-sm" style={{ borderColor: tier.color, color: tier.color }}>{tier.name}</Badge>}
            {team && <Link to={`/team/${team.id}`}><Badge variant="outline" className="text-sm border-gray-600 text-gray-400 hover:text-white">{team.name}</Badge></Link>}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-[#ff4655]">{player.rating.toFixed(1)}</p><p className="text-xs text-gray-400">Rating</p></div>
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-white">{player.stats.acs.toFixed(0)}</p><p className="text-xs text-gray-400">ACS</p></div>
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-white">{player.stats.kd.toFixed(2)}</p><p className="text-xs text-gray-400">K/D</p></div>
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-white">{player.stats.kast.toFixed(0)}%</p><p className="text-xs text-gray-400">KAST</p></div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="stats">
        <TabsList className="bg-[#1a202c] border border-[#2d3748]">
          <TabsTrigger value="stats" className="data-[state=active]:bg-[#ff4655]"><Target className="w-4 h-4 mr-2" />Estadísticas</TabsTrigger>
        </TabsList>

        <TabsContent value="stats" className="mt-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardHeader><CardTitle className="text-white text-lg flex items-center gap-2"><Crosshair className="w-5 h-5 text-[#ff4655]" />Combate</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between"><span className="text-gray-400">ACS</span><span className="text-white font-semibold">{player.stats.acs.toFixed(0)}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">ADR</span><span className="text-white font-semibold">{player.stats.adr.toFixed(0)}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">K/D</span><span className={`font-semibold ${player.stats.kd >= 1 ? 'text-green-400' : 'text-red-400'}`}>{player.stats.kd.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">KAST</span><span className="text-white font-semibold">{player.stats.kast.toFixed(0)}%</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Headshot %</span><span className="text-white font-semibold">{player.stats.headshotPercentage.toFixed(1)}%</span></div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardHeader><CardTitle className="text-white text-lg flex items-center gap-2"><Zap className="w-5 h-5 text-[#ff4655]" />Entrada</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between"><span className="text-gray-400">First Bloods</span><span className="text-white font-semibold">{player.stats.fb}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">First Deaths</span><span className="text-white font-semibold">{player.stats.fd}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">FK/FD Ratio</span><span className={`font-semibold ${player.stats.fkfd >= 1 ? 'text-green-400' : 'text-red-400'}`}>{player.stats.fkfd.toFixed(2)}</span></div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardHeader><CardTitle className="text-white text-lg flex items-center gap-2"><Award className="w-5 h-5 text-[#ff4655]" />Clutches</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between"><span className="text-gray-400">Clutches</span><span className="text-white font-semibold">{player.stats.clutches}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Clutches Ganados</span><span className="text-green-400 font-semibold">{player.stats.clutchesWon}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Ratio</span><span className="text-white font-semibold">{player.stats.clutches > 0 ? ((player.stats.clutchesWon / player.stats.clutches) * 100).toFixed(0) : 0}%</span></div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardHeader><CardTitle className="text-white text-lg flex items-center gap-2"><TrendingUp className="w-5 h-5 text-[#ff4655]" />Partidos</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between"><span className="text-gray-400">Jugados</span><span className="text-white font-semibold">{player.stats.matchesPlayed}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Victorias</span><span className="text-green-400 font-semibold">{player.stats.wins}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Derrotas</span><span className="text-red-400 font-semibold">{player.stats.losses}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Win Rate</span><span className="text-white font-semibold">{player.stats.matchesPlayed > 0 ? ((player.stats.wins / player.stats.matchesPlayed) * 100).toFixed(0) : 0}%</span></div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[#1a202c] border-[#2d3748] sm:col-span-2 lg:col-span-2">
              <CardHeader><CardTitle className="text-white text-lg flex items-center gap-2"><Target className="w-5 h-5 text-[#ff4655]" />Totales</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center"><p className="text-3xl font-bold text-white">{player.stats.kills}</p><p className="text-gray-400 text-sm">Kills</p></div>
                  <div className="text-center"><p className="text-3xl font-bold text-white">{player.stats.deaths}</p><p className="text-gray-400 text-sm">Deaths</p></div>
                  <div className="text-center"><p className="text-3xl font-bold text-white">{player.stats.assists}</p><p className="text-gray-400 text-sm">Assists</p></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
