import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Users, Search, Target, TrendingUp, Award } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useStore } from '@/store/useStore';
import { TIERS, ROLES, type Gender, type TierType, type PlayerRole } from '@/types';

function PlayerCard({ player }: { player: any }) {
  const { getTeam } = useStore();
  const team = player.teamId ? getTeam(player.teamId) : null;
  const tier = team ? TIERS.find(t => t.id === team.tier) : null;
  const role = ROLES.find(r => r.value === player.role);

  return (
    <Link to={`/player/${player.id}`}>
      <Card className="bg-[#1a202c] border-[#2d3748] hover:border-[#ff4655] transition-colors h-full">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded-lg flex items-center justify-center text-2xl font-bold text-white">{player.name.charAt(0)}</div>
            <div className="text-right"><span className="text-2xl font-bold text-[#ff4655]">{player.rating.toFixed(1)}</span><p className="text-xs text-gray-400">rating</p></div>
          </div>

          <h3 className="font-bold text-white text-lg mb-1">{player.name}</h3>
          {team && <p className="text-gray-400 text-sm mb-2">{team.name}</p>}
          
          <div className="flex items-center gap-2 mb-4">
            {player.role && <Badge variant="outline" className="text-xs" style={{ borderColor: role?.color, color: role?.color }}>{role?.label}</Badge>}
            {tier && <Badge variant="outline" className="text-xs" style={{ borderColor: tier.color, color: tier.color }}>{tier.name}</Badge>}
          </div>

          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#2d3748]">
            <div className="text-center"><div className="flex items-center justify-center gap-1 text-gray-400 text-xs mb-1"><Target className="w-3 h-3" />ACS</div><p className="font-semibold text-white">{player.stats.acs.toFixed(0)}</p></div>
            <div className="text-center"><div className="flex items-center justify-center gap-1 text-gray-400 text-xs mb-1"><TrendingUp className="w-3 h-3" />K/D</div><p className="font-semibold text-white">{player.stats.kd.toFixed(2)}</p></div>
            <div className="text-center"><div className="flex items-center justify-center gap-1 text-gray-400 text-xs mb-1"><Award className="w-3 h-3" />KAST</div><p className="font-semibold text-white">{player.stats.kast.toFixed(0)}%</p></div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export function Players() {
  const { players, teams } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRole, setSelectedRole] = useState<PlayerRole | 'all'>('all');
  const [selectedGender, setSelectedGender] = useState<Gender | 'all'>('all');
  const [selectedTier, setSelectedTier] = useState<TierType | 'all'>('all');

  const filteredPlayers = useMemo(() => {
    let filtered = [...players];
    if (searchQuery) filtered = filtered.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    if (selectedRole !== 'all') filtered = filtered.filter(p => p.role === selectedRole);
    if (selectedGender !== 'all') filtered = filtered.filter(p => { const team = p.teamId ? teams.find(t => t.id === p.teamId) : null; return team?.gender === selectedGender; });
    if (selectedTier !== 'all') filtered = filtered.filter(p => { const team = p.teamId ? teams.find(t => t.id === p.teamId) : null; return team?.tier === selectedTier; });
    return filtered.sort((a, b) => b.rating - a.rating);
  }, [players, searchQuery, selectedRole, selectedGender, selectedTier, teams]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3"><Users className="w-8 h-8 text-[#ff4655]" />Jugadores</h1>
          <p className="text-gray-400 mt-1">Todos los jugadores de las ligas españolas</p>
        </div>
      </div>

      <Card className="bg-[#1a202c] border-[#2d3748]">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Buscar jugadores..." className="pl-10 bg-[#0f1419] border-[#2d3748] text-white" />
            </div>
            <Select value={selectedRole} onValueChange={(v) => setSelectedRole(v as PlayerRole | 'all')}>
              <SelectTrigger className="w-full md:w-40 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Rol" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todos los roles</SelectItem>
                {ROLES.map(role => <SelectItem key={role.value} value={role.value}>{role.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={selectedGender} onValueChange={(v) => setSelectedGender(v as Gender | 'all')}>
              <SelectTrigger className="w-full md:w-40 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Género" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="masculino">Masculino</SelectItem>
                <SelectItem value="femenino">Femenino</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedTier} onValueChange={(v) => setSelectedTier(v as TierType | 'all')}>
              <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Liga" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todas las ligas</SelectItem>
                {TIERS.map(tier => <SelectItem key={tier.id} value={tier.id}>{tier.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {filteredPlayers.length > 0 ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">{filteredPlayers.map(player => <PlayerCard key={player.id} player={player} />)}</div> : <div className="text-center py-16 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]"><Users className="w-12 h-12 mx-auto mb-4 opacity-50" /><p className="text-lg">No se encontraron jugadores</p></div>}
    </div>
  );
}
