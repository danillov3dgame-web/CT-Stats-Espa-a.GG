import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Users, TrendingUp, Target } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/store/useStore';
import { TIERS } from '@/types';

export function TeamDetail() {
  const { id } = useParams<{ id: string }>();
  const { getTeam, getPlayer, rankings } = useStore();
  
  const team = id ? getTeam(id) : null;
  const ranking = rankings.find(r => r.teamId === id);
  
  if (!team) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400">Equipo no encontrado</p>
        <Link to="/teams"><Button variant="outline" className="mt-4"><ArrowLeft className="w-4 h-4 mr-2" />Volver a equipos</Button></Link>
      </div>
    );
  }

  const tier = TIERS.find(t => t.id === team.tier);
  const teamPlayers = team.players.map(pid => getPlayer(pid)).filter(Boolean);

  return (
    <div className="space-y-6">
      <Link to="/teams"><Button variant="ghost" className="text-gray-400 hover:text-white"><ArrowLeft className="w-4 h-4 mr-2" />Volver a equipos</Button></Link>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-24 h-24 md:w-32 md:h-32 bg-[#2d3748] rounded-xl flex items-center justify-center text-4xl md:text-5xl font-bold shrink-0">{team.shortName?.charAt(0) || team.name.charAt(0)}</div>
        
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl md:text-4xl font-bold text-white">{team.name}</h1>
            {team.shortName && <span className="text-gray-500 text-xl">[{team.shortName}]</span>}
          </div>
          
          <div className="flex flex-wrap items-center gap-2 mb-4">
            <Badge variant="outline" className="text-sm" style={{ borderColor: tier?.color, color: tier?.color }}>{tier?.name}</Badge>
            {ranking && <Badge variant="outline" className="text-sm border-[#ff4655] text-[#ff4655]">#{ranking.rank} en rankings</Badge>}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-white">{team.stats.matchesPlayed}</p><p className="text-xs text-gray-400">Partidos</p></div>
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-green-400">{team.stats.wins}</p><p className="text-xs text-gray-400">Victorias</p></div>
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-red-400">{team.stats.losses}</p><p className="text-xs text-gray-400">Derrotas</p></div>
            <div className="bg-[#1a202c] rounded-lg p-3"><p className="text-2xl font-bold text-white">{team.stats.matchesPlayed > 0 ? ((team.stats.wins / team.stats.matchesPlayed) * 100).toFixed(0) : 0}%</p><p className="text-xs text-gray-400">Win Rate</p></div>
          </div>
        </div>
      </div>

      {team.stats.recentForm.length > 0 && (
        <Card className="bg-[#1a202c] border-[#2d3748]">
          <CardHeader><CardTitle className="text-white flex items-center gap-2"><TrendingUp className="w-5 h-5 text-[#ff4655]" />Forma Reciente</CardTitle></CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {team.stats.recentForm.map((result, i) => <span key={i} className={`w-10 h-10 rounded-lg text-sm flex items-center justify-center font-bold ${result === 'W' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{result}</span>)}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="players">
        <TabsList className="bg-[#1a202c] border border-[#2d3748]">
          <TabsTrigger value="players" className="data-[state=active]:bg-[#ff4655]"><Users className="w-4 h-4 mr-2" />Jugadores</TabsTrigger>
          <TabsTrigger value="stats" className="data-[state=active]:bg-[#ff4655]"><Target className="w-4 h-4 mr-2" />Estadísticas</TabsTrigger>
        </TabsList>

        <TabsContent value="players" className="mt-6">
          {teamPlayers.length > 0 ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{teamPlayers.map(player => (
            <Link key={player!.id} to={`/player/${player!.id}`}>
              <Card className="bg-[#1a202c] border-[#2d3748] hover:border-[#ff4655] transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded-lg flex items-center justify-center text-xl font-bold text-white">{player!.name.charAt(0)}</div>
                    <div>
                      <h3 className="font-bold text-white">{player!.name}</h3>
                      {player!.role && <Badge variant="outline" className="text-xs mt-1">{player!.role}</Badge>}
                      <p className="text-[#ff4655] font-semibold mt-1">{player!.rating.toFixed(1)} rating</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}</div> : <div className="text-center py-16 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]"><Users className="w-12 h-12 mx-auto mb-4 opacity-50" /><p>No hay jugadores en este equipo</p></div>}
        </TabsContent>

        <TabsContent value="stats" className="mt-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardHeader><CardTitle className="text-white text-lg">Rondas</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between"><span className="text-gray-400">Ganadas</span><span className="text-green-400 font-semibold">{team.stats.roundsWon}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Perdidas</span><span className="text-red-400 font-semibold">{team.stats.roundsLost}</span></div>
                  <div className="flex justify-between border-t border-[#2d3748] pt-2"><span className="text-gray-400">Diferencia</span><span className={`font-semibold ${team.stats.roundsWon - team.stats.roundsLost >= 0 ? 'text-green-400' : 'text-red-400'}`}>{team.stats.roundsWon - team.stats.roundsLost > 0 ? '+' : ''}{team.stats.roundsWon - team.stats.roundsLost}</span></div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardHeader><CardTitle className="text-white text-lg">Torneos</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between"><span className="text-gray-400">Victorias</span><span className="text-yellow-400 font-semibold">{team.stats.tournamentWins}</span></div>
                  <div className="flex justify-between"><span className="text-gray-400">Top 4</span><span className="text-blue-400 font-semibold">{team.stats.tournamentTop4}</span></div>
                </div>
              </CardContent>
            </Card>
            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardHeader><CardTitle className="text-white text-lg">Rating</CardTitle></CardHeader>
              <CardContent>
                <div className="text-center"><p className="text-4xl font-bold text-[#ff4655]">{team.rating}</p><p className="text-gray-400 text-sm mt-1">Puntos de equipo</p></div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
