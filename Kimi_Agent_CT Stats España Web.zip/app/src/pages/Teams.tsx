import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Shield, Search, Users, TrendingUp, Trophy } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useStore } from '@/store/useStore';
import { TIERS, type Gender, type TierType } from '@/types';

function TeamCard({ team }: { team: any }) {
  const { players, rankings } = useStore();
  const tier = TIERS.find(t => t.id === team.tier);
  const teamPlayers = players.filter((p: any) => team.players.includes(p.id));
  const ranking = rankings.find((r: any) => r.teamId === team.id);

  return (
    <Link to={`/team/${team.id}`}>
      <Card className="bg-[#1a202c] border-[#2d3748] hover:border-[#ff4655] transition-colors h-full">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="w-16 h-16 bg-[#2d3748] rounded-lg flex items-center justify-center text-2xl font-bold">{team.shortName?.charAt(0) || team.name.charAt(0)}</div>
            {ranking && <div className="text-right"><span className="text-2xl font-bold text-[#ff4655]">#{ranking.rank}</span><p className="text-xs text-gray-400">{ranking.points} pts</p></div>}
          </div>

          <h3 className="font-bold text-white text-lg mb-1">{team.name}</h3>
          <Badge variant="outline" className="text-xs mb-4" style={{ borderColor: tier?.color, color: tier?.color }}>{tier?.name}</Badge>

          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#2d3748]">
            <div className="text-center"><div className="flex items-center justify-center gap-1 text-gray-400 text-xs mb-1"><Users className="w-3 h-3" />Jugadores</div><p className="font-semibold text-white">{teamPlayers.length}</p></div>
            <div className="text-center"><div className="flex items-center justify-center gap-1 text-gray-400 text-xs mb-1"><TrendingUp className="w-3 h-3" />Win Rate</div><p className="font-semibold text-white">{team.stats.matchesPlayed > 0 ? ((team.stats.wins / team.stats.matchesPlayed) * 100).toFixed(0) : 0}%</p></div>
            <div className="text-center"><div className="flex items-center justify-center gap-1 text-gray-400 text-xs mb-1"><Trophy className="w-3 h-3" />Victorias</div><p className="font-semibold text-white">{team.stats.wins}</p></div>
          </div>

          {team.stats.recentForm.length > 0 && (
            <div className="flex items-center justify-center gap-1 mt-4">
              {team.stats.recentForm.map((result: string, i: number) => <span key={i} className={`w-6 h-6 rounded text-xs flex items-center justify-center font-bold ${result === 'W' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{result}</span>)}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}

export function Teams() {
  const { teams } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGender, setSelectedGender] = useState<Gender | 'all'>('all');
  const [selectedTier, setSelectedTier] = useState<TierType | 'all'>('all');

  const filteredTeams = useMemo(() => {
    let filtered = [...teams];
    if (searchQuery) filtered = filtered.filter(t => t.name.toLowerCase().includes(searchQuery.toLowerCase()) || t.shortName?.toLowerCase().includes(searchQuery.toLowerCase()));
    if (selectedGender !== 'all') filtered = filtered.filter(t => t.gender === selectedGender);
    if (selectedTier !== 'all') filtered = filtered.filter(t => t.tier === selectedTier);
    return filtered.sort((a, b) => b.rating - a.rating);
  }, [teams, searchQuery, selectedGender, selectedTier]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3"><Shield className="w-8 h-8 text-[#ff4655]" />Equipos</h1>
          <p className="text-gray-400 mt-1">Todos los equipos de las ligas españolas</p>
        </div>
      </div>

      <Card className="bg-[#1a202c] border-[#2d3748]">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Buscar equipos..." className="pl-10 bg-[#0f1419] border-[#2d3748] text-white" />
            </div>
            <Select value={selectedGender} onValueChange={(v) => setSelectedGender(v as Gender | 'all')}>
              <SelectTrigger className="w-full md:w-40 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Género" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="masculino">Masculino</SelectItem>
                <SelectItem value="femenino">Femenino</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedTier} onValueChange={(v) => setSelectedTier(v as TierType | 'all')}>
              <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Liga" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todas las ligas</SelectItem>
                {TIERS.map(tier => <SelectItem key={tier.id} value={tier.id}>{tier.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {filteredTeams.length > 0 ? <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">{filteredTeams.map(team => <TeamCard key={team.id} team={team} />)}</div> : <div className="text-center py-16 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]"><Shield className="w-12 h-12 mx-auto mb-4 opacity-50" /><p className="text-lg">No se encontraron equipos</p></div>}
    </div>
  );
}
