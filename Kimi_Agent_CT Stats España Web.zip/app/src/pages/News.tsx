import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Newspaper, User, Search, Plus } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNews } from '@/store/useNews';
import { useAuth } from '@/store/useAuth';
const NEWS_TYPE_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  news: { bg: 'bg-blue-500/20', text: 'text-blue-400', label: 'Noticia' },
  transfer: { bg: 'bg-green-500/20', text: 'text-green-400', label: 'Fichaje' },
  rumor: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', label: 'Rumor' },
  announcement: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Anuncio' },
};

function NewsCard({ news }: { news: any }) {
  const typeStyle = NEWS_TYPE_COLORS[news.type];
  
  return (
    <Link to={`/news/${news.id}`}>
      <Card className="bg-[#1a202c] border-[#2d3748] hover:border-[#ff4655] transition-colors h-full">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-3">
            <Badge className={`${typeStyle.bg} ${typeStyle.text} border-0`}>
              {typeStyle.label}
            </Badge>
            <span className="text-gray-500 text-xs">
              {new Date(news.publishedAt || news.createdAt).toLocaleDateString('es-ES', {
                day: 'numeric',
                month: 'short',
              })}
            </span>
          </div>
          
          <h3 className="font-bold text-white text-lg mb-2 line-clamp-2">{news.title}</h3>
          
          {news.excerpt && (
            <p className="text-gray-400 text-sm mb-4 line-clamp-3">{news.excerpt}</p>
          )}
          
          <div className="flex items-center justify-between pt-4 border-t border-[#2d3748]">
            <div className="flex items-center gap-2 text-gray-500 text-sm">
              <User className="w-4 h-4" />
              <span>Autor</span>
            </div>
            {news.tags.length > 0 && (
              <div className="flex gap-1">
                {news.tags.slice(0, 2).map((tag: string) => (
                  <span key={tag} className="text-xs text-gray-400 bg-[#2d3748] px-2 py-1 rounded">
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

export function News() {
  const { publishedNews, isLoaded } = useNews();
  const { isEditor } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'all' | 'news' | 'transfers' | 'rumors'>('all');

  const filteredNews = useMemo(() => {
    let filtered = [...publishedNews];

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(n => 
        n.title.toLowerCase().includes(query) ||
        n.excerpt?.toLowerCase().includes(query) ||
        n.tags.some(t => t.toLowerCase().includes(query))
      );
    }

    if (selectedType !== 'all') {
      filtered = filtered.filter(n => n.type === selectedType);
    }

    if (activeTab === 'transfers') {
      filtered = filtered.filter(n => n.type === 'transfer');
    } else if (activeTab === 'rumors') {
      filtered = filtered.filter(n => n.type === 'rumor');
    }

    return filtered;
  }, [publishedNews, searchQuery, selectedType, activeTab]);

  const newsCounts = useMemo(() => ({
    all: publishedNews.length,
    news: publishedNews.filter(n => n.type === 'news').length,
    transfers: publishedNews.filter(n => n.type === 'transfer').length,
    rumors: publishedNews.filter(n => n.type === 'rumor').length,
  }), [publishedNews]);

  if (!isLoaded) {
    return <div className="flex items-center justify-center min-h-[60vh]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#ff4655]" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <Newspaper className="w-8 h-8 text-[#ff4655]" />
            Noticias
          </h1>
          <p className="text-gray-400 mt-1">Últimas noticias, fichajes y rumores</p>
        </div>
        {isEditor() && (
          <Link to="/news/create">
            <Button className="bg-[#ff4655] hover:bg-[#ff4655]/90">
              <Plus className="w-4 h-4 mr-2" />
              Nueva Noticia
            </Button>
          </Link>
        )}
      </div>

      <Card className="bg-[#1a202c] border-[#2d3748]">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar noticias..."
                className="pl-10 bg-[#0f1419] border-[#2d3748] text-white"
              />
            </div>
            <Select value={selectedType} onValueChange={(v) => setSelectedType(v)}>
              <SelectTrigger className="w-full md:w-40 bg-[#0f1419] border-[#2d3748] text-white">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="news">Noticias</SelectItem>
                <SelectItem value="transfer">Fichajes</SelectItem>
                <SelectItem value="rumor">Rumores</SelectItem>
                <SelectItem value="announcement">Anuncios</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
        <TabsList className="bg-[#1a202c] border border-[#2d3748]">
          <TabsTrigger value="all" className="data-[state=active]:bg-[#ff4655]">
            Todas ({newsCounts.all})
          </TabsTrigger>
          <TabsTrigger value="news" className="data-[state=active]:bg-blue-500">
            Noticias ({newsCounts.news})
          </TabsTrigger>
          <TabsTrigger value="transfers" className="data-[state=active]:bg-green-500">
            Fichajes ({newsCounts.transfers})
          </TabsTrigger>
          <TabsTrigger value="rumors" className="data-[state=active]:bg-yellow-500">
            Rumores ({newsCounts.rumors})
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {filteredNews.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredNews.map(item => <NewsCard key={item.id} news={item} />)}
            </div>
          ) : (
            <div className="text-center py-16 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]">
              <Newspaper className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg">No hay noticias disponibles</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
