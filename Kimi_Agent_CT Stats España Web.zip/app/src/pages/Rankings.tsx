import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Trophy, TrendingUp, TrendingDown, Users, Target } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/store/useStore';
import { TIERS, type Gender, type TierType } from '@/types';

function TeamRankingRow({ ranking, index }: { ranking: any; index: number }) {
  const { getTeam } = useStore();
  const team = getTeam(ranking.teamId);
  if (!team) return null;

  const rankChange = ranking.previousRank - ranking.rank;
  const tier = TIERS.find(t => t.id === ranking.tier);

  return (
    <div className="flex items-center gap-4 p-4 hover:bg-[#2d3748] transition-colors">
      <div className="w-12 text-center">
        <span className={`text-2xl font-bold ${index === 0 ? 'text-yellow-500' : index === 1 ? 'text-gray-300' : index === 2 ? 'text-amber-600' : 'text-white'}`}>{ranking.rank}</span>
        {rankChange !== 0 && <div className={`flex items-center justify-center text-xs ${rankChange > 0 ? 'text-green-400' : 'text-red-400'}`}>{rankChange > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}{Math.abs(rankChange)}</div>}
      </div>

      <Link to={`/team/${team.id}`} className="flex items-center gap-3 flex-1">
        <div className="w-12 h-12 bg-[#2d3748] rounded-lg flex items-center justify-center text-xl font-bold">{team.shortName?.charAt(0) || team.name.charAt(0)}</div>
        <div>
          <p className="font-semibold text-white">{team.name}</p>
          <Badge variant="outline" className="text-xs" style={{ borderColor: tier?.color, color: tier?.color }}>{tier?.name}</Badge>
        </div>
      </Link>

      <div className="hidden md:grid grid-cols-4 gap-8 text-center">
        <div><p className="text-lg font-bold text-white">{ranking.matchesPlayed}</p><p className="text-xs text-gray-400">Partidos</p></div>
        <div><p className="text-lg font-bold text-green-400">{ranking.wins}</p><p className="text-xs text-gray-400">Victorias</p></div>
        <div><p className="text-lg font-bold text-red-400">{ranking.losses}</p><p className="text-xs text-gray-400">Derrotas</p></div>
        <div><p className="text-lg font-bold text-white">{(ranking.winRate * 100).toFixed(0)}%</p><p className="text-xs text-gray-400">Win Rate</p></div>
      </div>

      <div className="w-24 text-right"><p className="text-2xl font-bold text-[#ff4655]">{ranking.points}</p><p className="text-xs text-gray-400">puntos</p></div>
    </div>
  );
}

function PlayerRankingRow({ player, index }: { player: any; index: number }) {
  const { getTeam } = useStore();
  const team = player.teamId ? getTeam(player.teamId) : null;

  return (
    <div className="flex items-center gap-4 p-4 hover:bg-[#2d3748] transition-colors">
      <div className="w-12 text-center">
        <span className={`text-2xl font-bold ${index === 0 ? 'text-yellow-500' : index === 1 ? 'text-gray-300' : index === 2 ? 'text-amber-600' : 'text-white'}`}>{index + 1}</span>
      </div>

      <Link to={`/player/${player.id}`} className="flex items-center gap-3 flex-1">
        <div className="w-12 h-12 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded-lg flex items-center justify-center text-xl font-bold text-white">{player.name.charAt(0)}</div>
        <div>
          <p className="font-semibold text-white">{player.name}</p>
          {team && <p className="text-sm text-gray-400">{team.name}</p>}
        </div>
      </Link>

      <div className="hidden sm:block w-24">
        {player.role && <Badge variant="outline" className="text-gray-400 border-gray-600">{player.role}</Badge>}
      </div>

      <div className="hidden md:grid grid-cols-5 gap-6 text-center">
        <div><p className="text-sm font-bold text-white">{player.stats.acs.toFixed(0)}</p><p className="text-xs text-gray-400">ACS</p></div>
        <div><p className="text-sm font-bold text-white">{player.stats.kd.toFixed(2)}</p><p className="text-xs text-gray-400">K/D</p></div>
        <div><p className="text-sm font-bold text-white">{player.stats.adr.toFixed(0)}</p><p className="text-xs text-gray-400">ADR</p></div>
        <div><p className="text-sm font-bold text-white">{player.stats.kast.toFixed(0)}%</p><p className="text-xs text-gray-400">KAST</p></div>
        <div><p className="text-sm font-bold text-white">{player.stats.matchesPlayed}</p><p className="text-xs text-gray-400">Partidos</p></div>
      </div>

      <div className="w-24 text-right"><p className="text-2xl font-bold text-[#ff4655]">{player.rating.toFixed(1)}</p><p className="text-xs text-gray-400">rating</p></div>
    </div>
  );
}

import { Badge } from '@/components/ui/badge';

export function Rankings() {
  const { rankings, players, teams, recalculateRankings } = useStore();
  const [selectedGender, setSelectedGender] = useState<Gender | 'all'>('all');
  const [selectedTier, setSelectedTier] = useState<TierType | 'all'>('all');

  const filteredTeamRankings = useMemo(() => {
    let filtered = [...rankings];
    if (selectedGender !== 'all') filtered = filtered.filter(r => r.gender === selectedGender);
    if (selectedTier !== 'all') filtered = filtered.filter(r => r.tier === selectedTier);
    return filtered.sort((a, b) => a.rank - b.rank);
  }, [rankings, selectedGender, selectedTier]);

  const filteredPlayerRankings = useMemo(() => {
    let filtered = [...players];
    if (selectedGender !== 'all') filtered = filtered.filter(p => { const team = p.teamId ? teams.find(t => t.id === p.teamId) : null; return team?.gender === selectedGender; });
    if (selectedTier !== 'all') filtered = filtered.filter(p => { const team = p.teamId ? teams.find(t => t.id === p.teamId) : null; return team?.tier === selectedTier; });
    return filtered.sort((a, b) => b.rating - a.rating);
  }, [players, teams, selectedGender, selectedTier]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3"><Trophy className="w-8 h-8 text-[#ff4655]" />Rankings</h1>
          <p className="text-gray-400 mt-1">Clasificaciones de equipos y jugadores</p>
        </div>
        <Button onClick={recalculateRankings} variant="outline" className="border-[#ff4655] text-[#ff4655] hover:bg-[#ff4655] hover:text-white"><TrendingUp className="w-4 h-4 mr-2" />Recalcular Rankings</Button>
      </div>

      <Card className="bg-[#1a202c] border-[#2d3748]">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <Select value={selectedGender} onValueChange={(v) => setSelectedGender(v as Gender | 'all')}>
              <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Todos los géneros" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todos los géneros</SelectItem>
                <SelectItem value="masculino">Masculino</SelectItem>
                <SelectItem value="femenino">Femenino</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedTier} onValueChange={(v) => setSelectedTier(v as TierType | 'all')}>
              <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Todas las ligas" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todas las ligas</SelectItem>
                {TIERS.map(tier => <SelectItem key={tier.id} value={tier.id}>{tier.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="teams">
        <TabsList className="bg-[#1a202c] border border-[#2d3748]">
          <TabsTrigger value="teams" className="data-[state=active]:bg-[#ff4655]"><Users className="w-4 h-4 mr-2" />Equipos</TabsTrigger>
          <TabsTrigger value="players" className="data-[state=active]:bg-[#ff4655]"><Target className="w-4 h-4 mr-2" />Jugadores</TabsTrigger>
        </TabsList>

        <TabsContent value="teams" className="mt-6">
          <Card className="bg-[#1a202c] border-[#2d3748]">
            <CardHeader className="border-b border-[#2d3748]">
              <div className="hidden md:grid grid-cols-[48px_1fr_320px_96px] gap-4 text-sm text-gray-400">
                <span className="text-center">#</span><span>Equipo</span><span className="text-center">Estadísticas</span><span className="text-right">Puntos</span>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {filteredTeamRankings.length > 0 ? <div className="divide-y divide-[#2d3748]">{filteredTeamRankings.map((ranking, index) => <TeamRankingRow key={ranking.teamId} ranking={ranking} index={index} />)}</div> : <div className="text-center py-16 text-gray-500"><Trophy className="w-12 h-12 mx-auto mb-4 opacity-50" /><p className="text-lg">No hay rankings disponibles</p></div>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="players" className="mt-6">
          <Card className="bg-[#1a202c] border-[#2d3748]">
            <CardHeader className="border-b border-[#2d3748]">
              <div className="hidden md:grid grid-cols-[48px_1fr_96px_280px_96px] gap-4 text-sm text-gray-400">
                <span className="text-center">#</span><span>Jugador</span><span>Rol</span><span className="text-center">Estadísticas</span><span className="text-right">Rating</span>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {filteredPlayerRankings.length > 0 ? <div className="divide-y divide-[#2d3748]">{filteredPlayerRankings.map((player, index) => <PlayerRankingRow key={player.id} player={player} index={index} />)}</div> : <div className="text-center py-16 text-gray-500"><Target className="w-12 h-12 mx-auto mb-4 opacity-50" /><p className="text-lg">No hay jugadores registrados</p></div>}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
