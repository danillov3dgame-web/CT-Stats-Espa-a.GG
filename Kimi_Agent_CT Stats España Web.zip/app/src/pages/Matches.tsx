import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Search } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useStore } from '@/store/useStore';
import { TIERS, type Match, type MatchStatus } from '@/types';

function MatchRow({ match }: { match: Match }) {
  const { getTeam, getEvent } = useStore();
  const teamA = getTeam(match.teamAId);
  const teamB = getTeam(match.teamBId);
  const event = getEvent(match.eventId);
  const tier = TIERS.find(t => t.id === match.tier);

  if (!teamA || !teamB) return null;

  const isLive = match.status === 'live';
  const isCompleted = match.status === 'completed';

  return (
    <Link to={`/match/${match.id}`}>
      <div className="bg-[#1a202c] rounded-lg p-4 hover:bg-[#2d3748] transition-colors border border-[#2d3748]">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <div className="flex items-center gap-3 lg:w-48">
            <Badge variant="outline" className="text-xs shrink-0" style={{ borderColor: tier?.color, color: tier?.color }}>{tier?.name}</Badge>
            {event && <span className="text-gray-400 text-xs truncate">{event.shortName || event.name}</span>}
          </div>

          <div className="flex-1 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1">
              <div className="w-10 h-10 bg-[#2d3748] rounded flex items-center justify-center shrink-0">{teamA.shortName?.charAt(0) || teamA.name.charAt(0)}</div>
              <span className="font-medium text-white hidden sm:block">{teamA.name}</span>
              <span className="font-medium text-white sm:hidden">{teamA.shortName || teamA.name}</span>
            </div>
            
            <div className="flex items-center gap-3 px-4">
              {isCompleted || isLive ? (
                <>
                  <span className={`text-2xl font-bold ${match.teamAScore > match.teamBScore ? 'text-white' : 'text-gray-500'}`}>{match.teamAScore}</span>
                  <span className="text-gray-500">:</span>
                  <span className={`text-2xl font-bold ${match.teamBScore > match.teamAScore ? 'text-white' : 'text-gray-500'}`}>{match.teamBScore}</span>
                </>
              ) : (
                <div className="text-center">
                  <span className="text-gray-500">vs</span>
                  <p className="text-xs text-gray-400 mt-1">{new Date(match.scheduledAt).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-3 flex-1 justify-end">
              <span className="font-medium text-white hidden sm:block text-right">{teamB.name}</span>
              <span className="font-medium text-white sm:hidden text-right">{teamB.shortName || teamB.name}</span>
              <div className="w-10 h-10 bg-[#2d3748] rounded flex items-center justify-center shrink-0">{teamB.shortName?.charAt(0) || teamB.name.charAt(0)}</div>
            </div>
          </div>

          <div className="lg:w-24 flex justify-end">
            {isLive && <Badge className="bg-red-500 text-white animate-pulse">EN VIVO</Badge>}
            {isCompleted && <Badge variant="outline" className="text-gray-400 border-gray-600">Finalizado</Badge>}
            {match.status === 'upcoming' && <Badge variant="outline" className="text-blue-400 border-blue-600">Próximo</Badge>}
          </div>
        </div>
      </div>
    </Link>
  );
}

export function Matches() {
  const { matches, events } = useStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTier, setSelectedTier] = useState<string>('all');
  const [selectedEvent, setSelectedEvent] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<MatchStatus | 'all'>('all');

  const { getTeam } = useStore();
  
  const filteredMatches = useMemo(() => {
    let filtered = matches;
    if (activeTab !== 'all') filtered = filtered.filter(m => m.status === activeTab);
    if (selectedTier !== 'all') filtered = filtered.filter(m => m.tier === selectedTier);
    if (selectedEvent !== 'all') filtered = filtered.filter(m => m.eventId === selectedEvent);
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(m => {
        const teamA = getTeam(m.teamAId);
        const teamB = getTeam(m.teamBId);
        return teamA?.name.toLowerCase().includes(query) || teamB?.name.toLowerCase().includes(query);
      });
    }
    return filtered.sort((a, b) => {
      if (a.status === 'live' && b.status !== 'live') return -1;
      if (b.status === 'live' && a.status !== 'live') return 1;
      if (a.status === 'upcoming' && b.status === 'upcoming') return new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime();
      if (a.status === 'completed' && b.status === 'completed') return new Date(b.completedAt || b.updatedAt).getTime() - new Date(a.completedAt || a.updatedAt).getTime();
      return 0;
    });
  }, [matches, activeTab, selectedTier, selectedEvent, searchQuery, getTeam]);

  const matchCounts = useMemo(() => ({
    all: matches.length,
    live: matches.filter(m => m.status === 'live').length,
    upcoming: matches.filter(m => m.status === 'upcoming').length,
    completed: matches.filter(m => m.status === 'completed').length,
  }), [matches]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Partidos</h1>
          <p className="text-gray-400 mt-1">Todos los partidos de las ligas españolas</p>
        </div>
      </div>

      <Card className="bg-[#1a202c] border-[#2d3748]">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Buscar equipos..." className="pl-10 bg-[#0f1419] border-[#2d3748] text-white" />
            </div>
            <Select value={selectedTier} onValueChange={setSelectedTier}>
              <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Todas las ligas" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todas las ligas</SelectItem>
                {TIERS.map(tier => <SelectItem key={tier.id} value={tier.id}>{tier.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={selectedEvent} onValueChange={setSelectedEvent}>
              <SelectTrigger className="w-full md:w-48 bg-[#0f1419] border-[#2d3748] text-white"><SelectValue placeholder="Todos los eventos" /></SelectTrigger>
              <SelectContent className="bg-[#1a202c] border-[#2d3748]">
                <SelectItem value="all">Todos los eventos</SelectItem>
                {events.map(event => <SelectItem key={event.id} value={event.id}>{event.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as MatchStatus | 'all')}>
        <TabsList className="bg-[#1a202c] border border-[#2d3748]">
          <TabsTrigger value="all" className="data-[state=active]:bg-[#ff4655]">Todos ({matchCounts.all})</TabsTrigger>
          <TabsTrigger value="live" className="data-[state=active]:bg-red-500">En Vivo ({matchCounts.live})</TabsTrigger>
          <TabsTrigger value="upcoming" className="data-[state=active]:bg-blue-500">Próximos ({matchCounts.upcoming})</TabsTrigger>
          <TabsTrigger value="completed" className="data-[state=active]:bg-green-500">Finalizados ({matchCounts.completed})</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          <div className="space-y-3">
            {filteredMatches.length > 0 ? filteredMatches.map(match => <MatchRow key={match.id} match={match} />) : <div className="text-center py-16 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]"><Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" /><p className="text-lg">No se encontraron partidos</p></div>}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
