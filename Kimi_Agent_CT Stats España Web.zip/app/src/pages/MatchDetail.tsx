import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useStore } from '@/store/useStore';
import { TIERS } from '@/types';

export function MatchDetail() {
  const { id } = useParams<{ id: string }>();
  const { getMatch, getTeam, getPlayer, getEvent } = useStore();
  
  const match = id ? getMatch(id) : null;
  
  if (!match) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400">Partido no encontrado</p>
        <Link to="/matches"><Button variant="outline" className="mt-4"><ArrowLeft className="w-4 h-4 mr-2" />Volver a partidos</Button></Link>
      </div>
    );
  }

  const teamA = getTeam(match.teamAId);
  const teamB = getTeam(match.teamBId);
  const event = getEvent(match.eventId);
  const tier = TIERS.find(t => t.id === match.tier);

  const isLive = match.status === 'live';
  const isCompleted = match.status === 'completed';

  return (
    <div className="space-y-6">
      <Link to="/matches"><Button variant="ghost" className="text-gray-400 hover:text-white"><ArrowLeft className="w-4 h-4 mr-2" />Volver a partidos</Button></Link>

      <Card className="bg-[#1a202c] border-[#2d3748]">
        <CardContent className="p-6">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Badge variant="outline" className="text-sm" style={{ borderColor: tier?.color, color: tier?.color }}>{tier?.name}</Badge>
            {event && <Link to={`/event/${event.id}`}><Badge variant="outline" className="text-sm border-gray-600 text-gray-400 hover:text-white">{event.name}</Badge></Link>}
            {isLive && <Badge className="bg-red-500 text-white animate-pulse"><span className="w-2 h-2 bg-white rounded-full mr-1" />EN VIVO</Badge>}
          </div>

          <div className="flex items-center justify-between gap-4">
            <Link to={`/team/${teamA?.id}`} className="flex-1">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 md:w-24 md:h-24 bg-[#2d3748] rounded-xl flex items-center justify-center text-3xl md:text-4xl font-bold mb-3">{teamA?.shortName?.charAt(0) || teamA?.name.charAt(0)}</div>
                <h2 className="text-xl md:text-2xl font-bold text-white text-center">{teamA?.name}</h2>
              </div>
            </Link>

            <div className="flex flex-col items-center px-4 md:px-8">
              {isCompleted || isLive ? (
                <>
                  <div className="flex items-center gap-4">
                    <span className={`text-5xl md:text-7xl font-bold ${match.teamAScore > match.teamBScore ? 'text-white' : 'text-gray-500'}`}>{match.teamAScore}</span>
                    <span className="text-3xl md:text-5xl text-gray-500">:</span>
                    <span className={`text-5xl md:text-7xl font-bold ${match.teamBScore > match.teamAScore ? 'text-white' : 'text-gray-500'}`}>{match.teamBScore}</span>
                  </div>
                  {isCompleted && <p className="text-gray-400 text-sm mt-2">Finalizado</p>}
                </>
              ) : (
                <div className="text-center">
                  <span className="text-4xl md:text-6xl text-gray-500">VS</span>
                  <p className="text-gray-400 text-sm mt-2">{new Date(match.scheduledAt).toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}</p>
                </div>
              )}
            </div>

            <Link to={`/team/${teamB?.id}`} className="flex-1">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 md:w-24 md:h-24 bg-[#2d3748] rounded-xl flex items-center justify-center text-3xl md:text-4xl font-bold mb-3">{teamB?.shortName?.charAt(0) || teamB?.name.charAt(0)}</div>
                <h2 className="text-xl md:text-2xl font-bold text-white text-center">{teamB?.name}</h2>
              </div>
            </Link>
          </div>

          {(match.streamUrl || match.vodUrl) && (
            <div className="flex justify-center gap-4 mt-6">
              {match.streamUrl && isLive && <a href={match.streamUrl} target="_blank" rel="noopener noreferrer"><Button className="bg-red-500 hover:bg-red-600"><Play className="w-4 h-4 mr-2" />Ver Stream</Button></a>}
              {match.vodUrl && isCompleted && <a href={match.vodUrl} target="_blank" rel="noopener noreferrer"><Button variant="outline" className="border-[#ff4655] text-[#ff4655]"><Play className="w-4 h-4 mr-2" />Ver VOD</Button></a>}
            </div>
          )}
        </CardContent>
      </Card>

      {match.maps.length > 0 && match.maps.map((map, index) => (
        <Card key={index} className="bg-[#1a202c] border-[#2d3748]">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-white mb-4">{map.map}</h3>
            <div className="grid lg:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">{teamA?.name} - {map.teamAScore}</h4>
                <div className="space-y-2">{map.teamAStats.map(stat => {
                  const player = getPlayer(stat.playerId);
                  if (!player) return null;
                  return (
                    <div key={stat.playerId} className="flex items-center justify-between p-2 bg-[#0f1419] rounded">
                      <div className="flex items-center gap-2"><div className="w-6 h-6 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded flex items-center justify-center text-xs font-bold text-white">{player.name.charAt(0)}</div><span className="text-white text-sm">{player.name}</span></div>
                      <div className="flex gap-4 text-sm"><span className="text-gray-400">{stat.kills}/{stat.deaths}/{stat.assists}</span><span className="text-[#ff4655]">{stat.acs} ACS</span></div>
                    </div>
                  );
                })}</div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">{teamB?.name} - {map.teamBScore}</h4>
                <div className="space-y-2">{map.teamBStats.map(stat => {
                  const player = getPlayer(stat.playerId);
                  if (!player) return null;
                  return (
                    <div key={stat.playerId} className="flex items-center justify-between p-2 bg-[#0f1419] rounded">
                      <div className="flex items-center gap-2"><div className="w-6 h-6 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded flex items-center justify-center text-xs font-bold text-white">{player.name.charAt(0)}</div><span className="text-white text-sm">{player.name}</span></div>
                      <div className="flex gap-4 text-sm"><span className="text-gray-400">{stat.kills}/{stat.deaths}/{stat.assists}</span><span className="text-[#ff4655]">{stat.acs} ACS</span></div>
                    </div>
                  );
                })}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
