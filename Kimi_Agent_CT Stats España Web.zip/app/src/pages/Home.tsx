import { useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Trophy, Users, TrendingUp, ChevronRight, Play, Clock, Newspaper } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useStore } from '@/store/useStore';
import { useNews } from '@/store/useNews';
import { TIERS, type Match } from '@/types';

function MatchCard({ match }: { match: Match }) {
  const { getTeam, getEvent } = useStore();
  const teamA = getTeam(match.teamAId);
  const teamB = getTeam(match.teamBId);
  const event = getEvent(match.eventId);
  const tier = TIERS.find(t => t.id === match.tier);

  if (!teamA || !teamB) return null;

  const isLive = match.status === 'live';
  const isCompleted = match.status === 'completed';

  return (
    <Link to={`/match/${match.id}`}>
      <div className="bg-[#1a202c] rounded-lg p-4 hover:bg-[#2d3748] transition-colors border border-[#2d3748]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs" style={{ borderColor: tier?.color, color: tier?.color }}>
              {tier?.name}
            </Badge>
            {event && <span className="text-gray-400 text-xs">{event.shortName || event.name}</span>}
          </div>
          {isLive && <Badge className="bg-red-500 text-white animate-pulse"><span className="w-2 h-2 bg-white rounded-full mr-1" />EN VIVO</Badge>}
          {!isLive && !isCompleted && (
            <div className="flex items-center gap-1 text-gray-400 text-xs">
              <Clock className="w-3 h-3" />
              {new Date(match.scheduledAt).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1">
            <div className="w-10 h-10 bg-[#2d3748] rounded flex items-center justify-center">{teamA.shortName?.charAt(0) || teamA.name.charAt(0)}</div>
            <span className="font-medium text-white">{teamA.shortName || teamA.name}</span>
          </div>
          
          <div className="flex items-center gap-3 px-4">
            {isCompleted || isLive ? (
              <>
                <span className={`text-2xl font-bold ${match.teamAScore > match.teamBScore ? 'text-white' : 'text-gray-500'}`}>{match.teamAScore}</span>
                <span className="text-gray-500">-</span>
                <span className={`text-2xl font-bold ${match.teamBScore > match.teamAScore ? 'text-white' : 'text-gray-500'}`}>{match.teamBScore}</span>
              </>
            ) : <span className="text-gray-500 text-sm">vs</span>}
          </div>
          
          <div className="flex items-center gap-3 flex-1 justify-end">
            <span className="font-medium text-white">{teamB.shortName || teamB.name}</span>
            <div className="w-10 h-10 bg-[#2d3748] rounded flex items-center justify-center">{teamB.shortName?.charAt(0) || teamB.name.charAt(0)}</div>
          </div>
        </div>
      </div>
    </Link>
  );
}

function EventCard({ event }: { event: any }) {
  const tier = TIERS.find(t => t.id === event.tier);
  
  return (
    <Link to={`/event/${event.id}`}>
      <div className="bg-[#1a202c] rounded-lg p-4 hover:bg-[#2d3748] transition-colors border border-[#2d3748]">
        <div className="flex items-start justify-between mb-2">
          <Badge variant="outline" className="text-xs" style={{ borderColor: tier?.color, color: tier?.color }}>{tier?.name}</Badge>
          <span className={`text-xs px-2 py-1 rounded ${event.status === 'ongoing' ? 'bg-green-500/20 text-green-400' : event.status === 'upcoming' ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-500/20 text-gray-400'}`}>
            {event.status === 'ongoing' ? 'En curso' : event.status === 'upcoming' ? 'Próximo' : 'Finalizado'}
          </span>
        </div>
        <h3 className="font-semibold text-white mb-1">{event.name}</h3>
        <p className="text-gray-400 text-sm mb-2">{event.teams.length} equipos</p>
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Calendar className="w-3 h-3" />
          {new Date(event.startDate).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })} - {new Date(event.endDate).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
        </div>
      </div>
    </Link>
  );
}

function NewsCard({ news }: { news: any }) {
  const typeColors: Record<string, { bg: string; text: string; label: string }> = {
    news: { bg: 'bg-blue-500/20', text: 'text-blue-400', label: 'Noticia' },
    transfer: { bg: 'bg-green-500/20', text: 'text-green-400', label: 'Fichaje' },
    rumor: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', label: 'Rumor' },
    announcement: { bg: 'bg-purple-500/20', text: 'text-purple-400', label: 'Anuncio' },
  };
  const typeStyle = typeColors[news.type];
  
  return (
    <Link to={`/news/${news.id}`}>
      <div className="bg-[#1a202c] rounded-lg p-4 hover:bg-[#2d3748] transition-colors border border-[#2d3748]">
        <div className="flex items-start justify-between mb-2">
          <Badge className={`${typeStyle.bg} ${typeStyle.text} border-0 text-xs`}>
            {typeStyle.label}
          </Badge>
          <span className="text-gray-500 text-xs">
            {new Date(news.publishedAt || news.createdAt).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
          </span>
        </div>
        <h3 className="font-semibold text-white text-sm line-clamp-2">{news.title}</h3>
      </div>
    </Link>
  );
}

export function Home() {
  const { matches, events, teams, players, rankings, recalculateRankings, isLoaded } = useStore();
  const { publishedNews } = useNews();

  useEffect(() => { if (isLoaded) recalculateRankings(); }, [isLoaded, recalculateRankings]);

  const liveMatches = useMemo(() => matches.filter(m => m.status === 'live').slice(0, 3), [matches]);
  const upcomingMatches = useMemo(() => matches.filter(m => m.status === 'upcoming').sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime()).slice(0, 5), [matches]);
  const recentMatches = useMemo(() => matches.filter(m => m.status === 'completed').sort((a, b) => new Date(b.completedAt || b.updatedAt).getTime() - new Date(a.completedAt || a.updatedAt).getTime()).slice(0, 5), [matches]);
  const ongoingEvents = useMemo(() => events.filter(e => e.status === 'ongoing'), [events]);
  const upcomingEvents = useMemo(() => events.filter(e => e.status === 'upcoming').sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime()).slice(0, 3), [events]);
  const topTeams = useMemo(() => rankings.sort((a, b) => a.rank - b.rank).slice(0, 5), [rankings]);
  const topPlayers = useMemo(() => players.sort((a, b) => b.rating - a.rating).slice(0, 5), [players]);
  const latestNews = useMemo(() => publishedNews.slice(0, 5), [publishedNews]);

  if (!isLoaded) return <div className="flex items-center justify-center min-h-[60vh]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#ff4655]" /></div>;

  return (
    <div className="space-y-8">
      <section className="relative bg-gradient-to-r from-[#ff4655]/20 to-[#0f1419] rounded-xl p-8 border border-[#2d3748]">
        <div className="max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded-xl flex items-center justify-center shadow-lg shadow-[#ff4655]/20">
              <span className="text-white font-black text-2xl tracking-tighter">CT</span>
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight">CT Stats</h1>
              <span className="text-[#ff4655] font-bold text-xl">España.GG</span>
            </div>
          </div>
          <p className="text-gray-300 text-lg mb-6">La plataforma líder de estadísticas para las ligas españolas de Valorant. Rankings en tiempo real, estadísticas detalladas, noticias y cobertura completa.</p>
          <div className="flex flex-wrap gap-3">
            <Link to="/matches"><Button className="bg-[#ff4655] hover:bg-[#ff4655]/90"><Play className="w-4 h-4 mr-2" />Ver Partidos</Button></Link>
            <Link to="/rankings"><Button variant="outline" className="border-[#2d3748] hover:bg-[#2d3748]"><Trophy className="w-4 h-4 mr-2" />Rankings</Button></Link>
            <Link to="/news"><Button variant="outline" className="border-[#2d3748] hover:bg-[#2d3748]"><Newspaper className="w-4 h-4 mr-2" />Noticias</Button></Link>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-8 pt-8 border-t border-[#2d3748]">
          <div className="text-center"><div className="text-3xl font-bold text-[#ff4655]">{teams.length}</div><div className="text-gray-400 text-sm">Equipos</div></div>
          <div className="text-center"><div className="text-3xl font-bold text-[#ff4655]">{players.length}</div><div className="text-gray-400 text-sm">Jugadores</div></div>
          <div className="text-center"><div className="text-3xl font-bold text-[#ff4655]">{matches.filter(m => m.status === 'completed').length}</div><div className="text-gray-400 text-sm">Partidos</div></div>
          <div className="text-center"><div className="text-3xl font-bold text-[#ff4655]">{events.length}</div><div className="text-gray-400 text-sm">Eventos</div></div>
          <div className="text-center"><div className="text-3xl font-bold text-[#ff4655]">{publishedNews.length}</div><div className="text-gray-400 text-sm">Noticias</div></div>
        </div>
      </section>

      {liveMatches.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2"><span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />En Vivo</h2>
          </div>
          <div className="grid gap-3">{liveMatches.map(match => <MatchCard key={match.id} match={match} />)}</div>
        </section>
      )}

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2"><Calendar className="w-5 h-5 text-[#ff4655]" />Próximos Partidos</h2>
              <Link to="/matches" className="text-[#ff4655] text-sm hover:underline flex items-center gap-1">Ver todos<ChevronRight className="w-4 h-4" /></Link>
            </div>
            <div className="grid gap-3">
              {upcomingMatches.length > 0 ? upcomingMatches.map(match => <MatchCard key={match.id} match={match} />) : <div className="text-center py-8 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]">No hay partidos programados</div>}
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2"><TrendingUp className="w-5 h-5 text-[#ff4655]" />Resultados Recientes</h2>
              <Link to="/matches" className="text-[#ff4655] text-sm hover:underline flex items-center gap-1">Ver todos<ChevronRight className="w-4 h-4" /></Link>
            </div>
            <div className="grid gap-3">
              {recentMatches.length > 0 ? recentMatches.map(match => <MatchCard key={match.id} match={match} />) : <div className="text-center py-8 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]">No hay resultados recientes</div>}
            </div>
          </section>
        </div>

        <div className="space-y-8">
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2"><Trophy className="w-5 h-5 text-[#ff4655]" />Eventos</h2>
              <Link to="/events" className="text-[#ff4655] text-sm hover:underline">Ver todos</Link>
            </div>
            <div className="space-y-3">
              {ongoingEvents.length > 0 && <div><p className="text-xs text-gray-500 uppercase mb-2">En curso</p>{ongoingEvents.map(event => <EventCard key={event.id} event={event} />)}</div>}
              {upcomingEvents.length > 0 && <div><p className="text-xs text-gray-500 uppercase mb-2">Próximos</p>{upcomingEvents.map(event => <EventCard key={event.id} event={event} />)}</div>}
              {ongoingEvents.length === 0 && upcomingEvents.length === 0 && <div className="text-center py-8 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]">No hay eventos activos</div>}
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2"><Newspaper className="w-5 h-5 text-[#ff4655]" />Últimas Noticias</h2>
              <Link to="/news" className="text-[#ff4655] text-sm hover:underline">Ver todas</Link>
            </div>
            <div className="space-y-3">
              {latestNews.length > 0 ? latestNews.map(news => <NewsCard key={news.id} news={news} />) : <div className="text-center py-8 text-gray-500 bg-[#1a202c] rounded-lg border border-[#2d3748]">No hay noticias disponibles</div>}
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2"><Trophy className="w-5 h-5 text-[#ff4655]" />Top Equipos</h2>
              <Link to="/rankings" className="text-[#ff4655] text-sm hover:underline">Ver rankings</Link>
            </div>
            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardContent className="p-0">
                {topTeams.length > 0 ? <div className="divide-y divide-[#2d3748]">
                  {topTeams.map((ranking, index) => {
                    const team = teams.find(t => t.id === ranking.teamId);
                    if (!team) return null;
                    return (
                      <Link key={team.id} to={`/team/${team.id}`} className="flex items-center gap-3 p-3 hover:bg-[#2d3748] transition-colors">
                        <span className={`w-6 h-6 rounded flex items-center justify-center text-sm font-bold ${index === 0 ? 'bg-yellow-500 text-black' : index === 1 ? 'bg-gray-400 text-black' : index === 2 ? 'bg-amber-600 text-white' : 'bg-[#2d3748] text-gray-400'}`}>{ranking.rank}</span>
                        <div className="w-8 h-8 bg-[#2d3748] rounded flex items-center justify-center text-sm">{team.shortName?.charAt(0) || team.name.charAt(0)}</div>
                        <div className="flex-1 min-w-0"><p className="font-medium text-white truncate">{team.name}</p><p className="text-xs text-gray-400">{ranking.points} pts</p></div>
                      </Link>
                    );
                  })}
                </div> : <div className="text-center py-8 text-gray-500">No hay rankings disponibles</div>}
              </CardContent>
            </Card>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2"><Users className="w-5 h-5 text-[#ff4655]" />Top Jugadores</h2>
              <Link to="/players" className="text-[#ff4655] text-sm hover:underline">Ver todos</Link>
            </div>
            <Card className="bg-[#1a202c] border-[#2d3748]">
              <CardContent className="p-0">
                {topPlayers.length > 0 ? <div className="divide-y divide-[#2d3748]">
                  {topPlayers.map((player, index) => (
                    <Link key={player.id} to={`/player/${player.id}`} className="flex items-center gap-3 p-3 hover:bg-[#2d3748] transition-colors">
                      <span className={`w-6 h-6 rounded flex items-center justify-center text-sm font-bold ${index === 0 ? 'bg-yellow-500 text-black' : index === 1 ? 'bg-gray-400 text-black' : index === 2 ? 'bg-amber-600 text-white' : 'bg-[#2d3748] text-gray-400'}`}>{index + 1}</span>
                      <div className="flex-1 min-w-0"><p className="font-medium text-white truncate">{player.name}</p><p className="text-xs text-gray-400">{player.role || 'Flex'}</p></div>
                      <div className="text-right"><p className="font-bold text-[#ff4655]">{player.rating.toFixed(1)}</p><p className="text-xs text-gray-400">Rating</p></div>
                    </Link>
                  ))}
                </div> : <div className="text-center py-8 text-gray-500">No hay jugadores registrados</div>}
              </CardContent>
            </Card>
          </section>
        </div>
      </div>
    </div>
  );
}
