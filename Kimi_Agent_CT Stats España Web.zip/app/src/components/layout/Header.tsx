import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/store/useAuth';
import { TIERS } from '@/types';

const navItems = [
  { path: '/', label: 'Inicio' },
  { path: '/matches', label: 'Partidos' },
  { path: '/rankings', label: 'Rankings' },
  { path: '/teams', label: 'Equipos' },
  { path: '/players', label: 'Jugadores' },
  { path: '/events', label: 'Eventos' },
  { path: '/news', label: 'Noticias' },
];

const tierGroups = {
  masculino: TIERS.filter(t => t.gender === 'masculino'),
  femenino: TIERS.filter(t => t.gender === 'femenino'),
  torneo: TIERS.filter(t => t.gender === 'torneo'),
};

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="w-10 h-10 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded-lg flex items-center justify-center shadow-lg shadow-[#ff4655]/20">
        <span className="text-white font-black text-lg tracking-tighter">CT</span>
      </div>
      <div className="hidden sm:block">
        <span className="text-white font-bold text-lg leading-tight">CT Stats</span>
        <span className="text-[#ff4655] font-bold text-lg leading-tight block -mt-1">España.GG</span>
      </div>
    </div>
  );
}

export function Header() {
  const location = useLocation();
  const { isAuthenticated, currentUser, logout, isAdmin, isEditor } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 w-full bg-[#0f1419]/95 backdrop-blur-sm border-b border-[#2d3748]">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/">
            <Logo />
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive(item.path)
                    ? 'bg-[#ff4655] text-white'
                    : 'text-gray-300 hover:text-white hover:bg-[#1a202c]'
                }`}
              >
                {item.label}
              </Link>
            ))}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-[#1a202c] flex items-center gap-1">
                  Ligas
                  <ChevronDown className="w-4 h-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-[#1a202c] border-[#2d3748]">
                <div className="p-2">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-2 px-2">Masculino</p>
                  {tierGroups.masculino.map((tier) => (
                    <DropdownMenuItem key={tier.id} asChild>
                      <Link to={`/tier/${tier.id}`} className="flex items-center gap-2 text-gray-300 hover:text-white hover:bg-[#2d3748] cursor-pointer">
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: tier.color }} />
                        {tier.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </div>
                <div className="p-2 border-t border-[#2d3748]">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-2 px-2">Femenino</p>
                  {tierGroups.femenino.map((tier) => (
                    <DropdownMenuItem key={tier.id} asChild>
                      <Link to={`/tier/${tier.id}`} className="flex items-center gap-2 text-gray-300 hover:text-white hover:bg-[#2d3748] cursor-pointer">
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: tier.color }} />
                        {tier.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </div>
                <div className="p-2 border-t border-[#2d3748]">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-2 px-2">Torneos</p>
                  {tierGroups.torneo.map((tier) => (
                    <DropdownMenuItem key={tier.id} asChild>
                      <Link to={`/tier/${tier.id}`} className="flex items-center gap-2 text-gray-300 hover:text-white hover:bg-[#2d3748] cursor-pointer">
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: tier.color }} />
                        {tier.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          <div className="hidden lg:flex items-center gap-2">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-[#1a202c]">
                    <div className="w-8 h-8 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-sm">
                        {currentUser?.displayName?.charAt(0) || currentUser?.username.charAt(0)}
                      </span>
                    </div>
                    <span className="hidden xl:inline">{currentUser?.displayName || currentUser?.username}</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-48 bg-[#1a202c] border-[#2d3748]">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium text-white">{currentUser?.displayName}</p>
                    <p className="text-xs text-gray-400">@{currentUser?.username}</p>
                    <Badge className="mt-1 text-xs" variant={currentUser?.role === 'admin' ? 'default' : 'secondary'}>
                      {currentUser?.role === 'admin' ? 'Administrador' : currentUser?.role === 'editor' ? 'Editor' : 'Usuario'}
                    </Badge>
                  </div>
                  <DropdownMenuSeparator className="bg-[#2d3748]" />
                  {(isAdmin() || isEditor()) && (
                    <DropdownMenuItem asChild>
                      <Link to="/admin" className="text-gray-300 hover:text-white hover:bg-[#2d3748] cursor-pointer">
                        Panel Admin
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="text-gray-300 hover:text-white hover:bg-[#2d3748] cursor-pointer">
                      Mi Perfil
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-[#2d3748]" />
                  <DropdownMenuItem onClick={logout} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 cursor-pointer">
                    <LogOut className="w-4 h-4 mr-2" />
                    Cerrar Sesión
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost" className="text-gray-300 hover:text-white">Iniciar Sesión</Button>
                </Link>
                <Link to="/register">
                  <Button className="bg-[#ff4655] hover:bg-[#ff4655]/90">Registrarse</Button>
                </Link>
              </>
            )}
          </div>

          <button className="lg:hidden p-2 text-gray-300 hover:text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#1a202c] border-t border-[#2d3748]">
          <nav className="flex flex-col p-4 gap-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-4 py-3 rounded-md text-sm font-medium transition-colors ${
                  isActive(item.path) ? 'bg-[#ff4655] text-white' : 'text-gray-300 hover:text-white hover:bg-[#2d3748]'
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <div className="border-t border-[#2d3748] pt-2 mt-2">
              <p className="text-xs font-semibold text-gray-500 uppercase mb-2 px-4">Ligas y Torneos</p>
              {TIERS.map((tier) => (
                <Link
                  key={tier.id}
                  to={`/tier/${tier.id}`}
                  className="flex items-center gap-2 px-4 py-2 text-gray-300 hover:text-white hover:bg-[#2d3748]"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: tier.color }} />
                  {tier.name}
                </Link>
              ))}
            </div>
            {isAuthenticated ? (
              <>
                <div className="border-t border-[#2d3748] pt-2 mt-2">
                  <p className="text-xs font-semibold text-gray-500 uppercase mb-2 px-4">Cuenta</p>
                  <div className="px-4 py-2">
                    <p className="text-white font-medium">{currentUser?.displayName}</p>
                    <p className="text-gray-400 text-sm">@{currentUser?.username}</p>
                  </div>
                  {(isAdmin() || isEditor()) && (
                    <Link to="/admin" className="block px-4 py-2 text-gray-300 hover:text-white hover:bg-[#2d3748]" onClick={() => setMobileMenuOpen(false)}>
                      Panel Admin
                    </Link>
                  )}
                  <button onClick={() => { logout(); setMobileMenuOpen(false); }} className="w-full text-left px-4 py-2 text-red-400 hover:text-red-300 hover:bg-red-500/10">
                    Cerrar Sesión
                  </button>
                </div>
              </>
            ) : (
              <div className="border-t border-[#2d3748] pt-2 mt-2 flex gap-2 px-4">
                <Link to="/login" className="flex-1" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="outline" className="w-full border-[#2d3748]">Iniciar Sesión</Button>
                </Link>
                <Link to="/register" className="flex-1" onClick={() => setMobileMenuOpen(false)}>
                  <Button className="w-full bg-[#ff4655] hover:bg-[#ff4655]/90">Registrarse</Button>
                </Link>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}

// Import Badge
import { Badge } from '@/components/ui/badge';
