import { Link } from 'react-router-dom';
import { Twitter, Youtube, Twitch, Instagram } from 'lucide-react';

function Logo() {
  return (
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 bg-gradient-to-br from-[#ff4655] to-[#ff6b35] rounded flex items-center justify-center">
        <span className="text-white font-black text-sm tracking-tighter">CT</span>
      </div>
      <div>
        <span className="text-white font-bold">CT Stats</span>
        <span className="text-[#ff4655] font-bold">.GG</span>
      </div>
    </div>
  );
}

export function Footer() {
  return (
    <footer className="bg-[#0f1419] border-t border-[#2d3748] mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Logo />
            </div>
            <p className="text-gray-400 text-sm mb-4 max-w-md">
              La plataforma líder de estadísticas para las ligas españolas de Valorant. 
              Rankings, partidos, fichajes y noticias en tiempo real.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Youtube className="w-5 h-5" /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Twitch className="w-5 h-5" /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Instagram className="w-5 h-5" /></a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white text-sm transition-colors">Inicio</Link></li>
              <li><Link to="/matches" className="text-gray-400 hover:text-white text-sm transition-colors">Partidos</Link></li>
              <li><Link to="/rankings" className="text-gray-400 hover:text-white text-sm transition-colors">Rankings</Link></li>
              <li><Link to="/teams" className="text-gray-400 hover:text-white text-sm transition-colors">Equipos</Link></li>
              <li><Link to="/news" className="text-gray-400 hover:text-white text-sm transition-colors">Noticias</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Competiciones</h3>
            <ul className="space-y-2">
              <li><Link to="/tier/LR" className="text-gray-400 hover:text-white text-sm transition-colors">Liga Radiante</Link></li>
              <li><Link to="/tier/DIV 1" className="text-gray-400 hover:text-white text-sm transition-colors">División 1</Link></li>
              <li><Link to="/tier/DIV 2" className="text-gray-400 hover:text-white text-sm transition-colors">División 2</Link></li>
              <li><Link to="/tier/LRF" className="text-gray-400 hover:text-white text-sm transition-colors">Liga Radiante Femenina</Link></li>
              <li><Link to="/tier/GC" className="text-gray-400 hover:text-white text-sm transition-colors">Game Changers</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-[#2d3748] mt-8 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            © 2024 CT Stats España.GG - No afiliado con Riot Games.
          </p>
          <div className="flex gap-6">
            <Link to="/privacy" className="text-gray-500 hover:text-gray-400 text-sm">Privacidad</Link>
            <Link to="/terms" className="text-gray-500 hover:text-gray-400 text-sm">Términos</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
