import { useState } from 'react';
import { X, Plus, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useStore } from '@/store/useStore';
import type { Match, MapResult, PlayerMatchStats } from '@/types';

const VALORANT_AGENTS = [
  'Astra', 'Breach', 'Brimstone', 'Chamber', 'Cypher', 'Deadlock', 'Fade', 'Gekko',
  'Harbor', 'Iso', 'Jett', 'KAY/O', 'Killjoy', 'Neon', 'Omen', 'Phoenix',
  'Raze', 'Reyna', 'Sage', 'Skye', 'Sova', 'Viper', 'Yoru', 'Clove', 'Vyse'
];

const VALORANT_MAPS = ['Ascent', 'Bind', 'Breeze', 'Fracture', 'Haven', 'Icebox', 'Lotus', 'Pearl', 'Split', 'Sunset'];

interface MatchResultFormProps {
  match: Match;
  onSave: () => void;
  onCancel: () => void;
}

function PlayerStatsRow({ 
  player, 
  stats, 
  onChange 
}: { 
  player: any; 
  stats: PlayerMatchStats; 
  onChange: (stats: PlayerMatchStats) => void;
}) {
  const updateStat = (field: keyof PlayerMatchStats, value: any) => {
    onChange({ ...stats, [field]: value });
  };

  return (
    <div className="grid grid-cols-12 gap-2 items-center p-2 bg-[#0f1419] rounded">
      <div className="col-span-2">
        <span className="text-white text-sm font-medium">{player?.name || 'Jugador'}</span>
      </div>
      <div className="col-span-2">
        <Select value={stats.agent} onValueChange={(v) => updateStat('agent', v)}>
          <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Agente" /></SelectTrigger>
          <SelectContent>{VALORANT_AGENTS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div className="col-span-1"><Input type="number" value={stats.kills} onChange={(e) => updateStat('kills', parseInt(e.target.value) || 0)} className="h-8 text-center" /></div>
      <div className="col-span-1"><Input type="number" value={stats.deaths} onChange={(e) => updateStat('deaths', parseInt(e.target.value) || 0)} className="h-8 text-center" /></div>
      <div className="col-span-1"><Input type="number" value={stats.assists} onChange={(e) => updateStat('assists', parseInt(e.target.value) || 0)} className="h-8 text-center" /></div>
      <div className="col-span-1"><Input type="number" value={stats.acs} onChange={(e) => updateStat('acs', parseInt(e.target.value) || 0)} className="h-8 text-center" /></div>
      <div className="col-span-1"><Input type="number" value={stats.adr} onChange={(e) => updateStat('adr', parseInt(e.target.value) || 0)} className="h-8 text-center" /></div>
      <div className="col-span-1"><Input type="number" value={stats.kast} onChange={(e) => updateStat('kast', parseInt(e.target.value) || 0)} className="h-8 text-center" max={100} /></div>
      <div className="col-span-1"><Input type="number" value={stats.fb} onChange={(e) => updateStat('fb', parseInt(e.target.value) || 0)} className="h-8 text-center" /></div>
      <div className="col-span-1"><Input type="number" value={stats.fd} onChange={(e) => updateStat('fd', parseInt(e.target.value) || 0)} className="h-8 text-center" /></div>
    </div>
  );
}

export function MatchResultForm({ match, onSave, onCancel }: MatchResultFormProps) {
  const { getTeam, getPlayer, updateMatch } = useStore();
  const teamA = getTeam(match.teamAId);
  const teamB = getTeam(match.teamBId);
  
  const [maps, setMaps] = useState<MapResult[]>(match.maps.length > 0 ? match.maps : [{
    map: '',
    teamAScore: 0,
    teamBScore: 0,
    teamAStats: teamA?.players.map(pid => ({
      playerId: pid,
      agent: '',
      kills: 0,
      deaths: 0,
      assists: 0,
      acs: 0,
      adr: 0,
      kast: 0,
      fb: 0,
      fd: 0,
      headshots: 0,
      bodyshots: 0,
      legshots: 0,
      econRating: 0,
      plants: 0,
      defuses: 0,
      clutches: 0,
      clutchesWon: 0,
      firstKills: 0,
      firstDeaths: 0,
      multiKills: [0, 0, 0, 0, 0],
    })) || [],
    teamBStats: teamB?.players.map(pid => ({
      playerId: pid,
      agent: '',
      kills: 0,
      deaths: 0,
      assists: 0,
      acs: 0,
      adr: 0,
      kast: 0,
      fb: 0,
      fd: 0,
      headshots: 0,
      bodyshots: 0,
      legshots: 0,
      econRating: 0,
      plants: 0,
      defuses: 0,
      clutches: 0,
      clutchesWon: 0,
      firstKills: 0,
      firstDeaths: 0,
      multiKills: [0, 0, 0, 0, 0],
    })) || [],
  }]);

  const updateMap = (index: number, updates: Partial<MapResult>) => {
    setMaps(prev => prev.map((m, i) => i === index ? { ...m, ...updates } : m));
  };

  const updatePlayerStats = (mapIndex: number, team: 'A' | 'B', playerId: string, stats: PlayerMatchStats) => {
    setMaps(prev => prev.map((m, i) => {
      if (i !== mapIndex) return m;
      if (team === 'A') {
        return { ...m, teamAStats: m.teamAStats.map(s => s.playerId === playerId ? stats : s) };
      }
      return { ...m, teamBStats: m.teamBStats.map(s => s.playerId === playerId ? stats : s) };
    }));
  };

  const addMap = () => {
    setMaps(prev => [...prev, {
      map: '',
      teamAScore: 0,
      teamBScore: 0,
      teamAStats: teamA?.players.map(pid => ({
        playerId: pid,
        agent: '',
        kills: 0,
        deaths: 0,
        assists: 0,
        acs: 0,
        adr: 0,
        kast: 0,
        fb: 0,
        fd: 0,
        headshots: 0,
        bodyshots: 0,
        legshots: 0,
        econRating: 0,
        plants: 0,
        defuses: 0,
        clutches: 0,
        clutchesWon: 0,
        firstKills: 0,
        firstDeaths: 0,
        multiKills: [0, 0, 0, 0, 0],
      })) || [],
      teamBStats: teamB?.players.map(pid => ({
        playerId: pid,
        agent: '',
        kills: 0,
        deaths: 0,
        assists: 0,
        acs: 0,
        adr: 0,
        kast: 0,
        fb: 0,
        fd: 0,
        headshots: 0,
        bodyshots: 0,
        legshots: 0,
        econRating: 0,
        plants: 0,
        defuses: 0,
        clutches: 0,
        clutchesWon: 0,
        firstKills: 0,
        firstDeaths: 0,
        multiKills: [0, 0, 0, 0, 0],
      })) || [],
    }]);
  };

  const removeMap = (index: number) => {
    setMaps(prev => prev.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    // Calcular score total
    const totalAScore = maps.reduce((sum, m) => sum + (m.teamAScore > m.teamBScore ? 1 : 0), 0);
    const totalBScore = maps.reduce((sum, m) => sum + (m.teamBScore > m.teamAScore ? 1 : 0), 0);

    updateMatch(match.id, {
      teamAScore: totalAScore,
      teamBScore: totalBScore,
      maps,
      status: 'completed',
    });

    onSave();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Añadir Resultado - {teamA?.name} vs {teamB?.name}</h2>
        <Button variant="ghost" onClick={onCancel}><X className="w-4 h-4" /></Button>
      </div>

      {maps.map((map, mapIndex) => (
        <Card key={mapIndex} className="bg-[#1a202c] border-[#2d3748]">
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="flex items-center gap-4">
              <Select value={map.map} onValueChange={(v) => updateMap(mapIndex, { map: v })}>
                <SelectTrigger className="w-40"><SelectValue placeholder="Seleccionar mapa" /></SelectTrigger>
                <SelectContent>{VALORANT_MAPS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <div className="flex items-center gap-2">
                <Input 
                  type="number" 
                  value={map.teamAScore} 
                  onChange={(e) => updateMap(mapIndex, { teamAScore: parseInt(e.target.value) || 0 })}
                  className="w-16 text-center"
                />
                <span className="text-gray-400">:</span>
                <Input 
                  type="number" 
                  value={map.teamBScore} 
                  onChange={(e) => updateMap(mapIndex, { teamBScore: parseInt(e.target.value) || 0 })}
                  className="w-16 text-center"
                />
              </div>
            </div>
            {maps.length > 1 && (
              <Button variant="ghost" size="sm" onClick={() => removeMap(mapIndex)} className="text-red-400">
                <X className="w-4 h-4" />
              </Button>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Team A Stats */}
            <div>
              <h4 className="text-white font-semibold mb-2">{teamA?.name}</h4>
              <div className="grid grid-cols-12 gap-2 text-xs text-gray-400 mb-1">
                <div className="col-span-2">Jugador</div>
                <div className="col-span-2">Agente</div>
                <div className="col-span-1 text-center">K</div>
                <div className="col-span-1 text-center">D</div>
                <div className="col-span-1 text-center">A</div>
                <div className="col-span-1 text-center">ACS</div>
                <div className="col-span-1 text-center">ADR</div>
                <div className="col-span-1 text-center">KAST</div>
                <div className="col-span-1 text-center">FB</div>
                <div className="col-span-1 text-center">FD</div>
              </div>
              <div className="space-y-1">
                {map.teamAStats.map((stats) => {
                  const player = getPlayer(stats.playerId);
                  return (
                    <PlayerStatsRow
                      key={stats.playerId}
                      player={player}
                      stats={stats}
                      onChange={(s) => updatePlayerStats(mapIndex, 'A', stats.playerId, s)}
                    />
                  );
                })}
              </div>
            </div>

            {/* Team B Stats */}
            <div>
              <h4 className="text-white font-semibold mb-2">{teamB?.name}</h4>
              <div className="grid grid-cols-12 gap-2 text-xs text-gray-400 mb-1">
                <div className="col-span-2">Jugador</div>
                <div className="col-span-2">Agente</div>
                <div className="col-span-1 text-center">K</div>
                <div className="col-span-1 text-center">D</div>
                <div className="col-span-1 text-center">A</div>
                <div className="col-span-1 text-center">ACS</div>
                <div className="col-span-1 text-center">ADR</div>
                <div className="col-span-1 text-center">KAST</div>
                <div className="col-span-1 text-center">FB</div>
                <div className="col-span-1 text-center">FD</div>
              </div>
              <div className="space-y-1">
                {map.teamBStats.map((stats) => {
                  const player = getPlayer(stats.playerId);
                  return (
                    <PlayerStatsRow
                      key={stats.playerId}
                      player={player}
                      stats={stats}
                      onChange={(s) => updatePlayerStats(mapIndex, 'B', stats.playerId, s)}
                    />
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      <div className="flex gap-4">
        <Button onClick={addMap} variant="outline" className="border-[#2d3748]">
          <Plus className="w-4 h-4 mr-2" />
          Añadir Mapa
        </Button>
        <Button onClick={handleSave} className="bg-[#ff4655] hover:bg-[#ff4655]/90">
          <Save className="w-4 h-4 mr-2" />
          Guardar Resultado
        </Button>
      </div>
    </div>
  );
}
